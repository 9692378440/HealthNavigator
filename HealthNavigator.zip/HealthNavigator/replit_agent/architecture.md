# Architecture Overview

## 1. Overview

HealthGuide is a full-stack web application that provides medical information, symptom analysis, drug interaction checking, and nearby medical service location features. The application follows a modern client-server architecture with a React frontend and Express.js backend, using a PostgreSQL database with Drizzle ORM for data persistence.

The system is designed to help users:
- Search for medicine information
- Check drug interactions
- Analyze symptoms to identify possible conditions
- Find nearby medical services
- Manage personal health profiles

## 2. System Architecture

The application follows a typical three-tier architecture:

1. **Frontend (Client)**: React-based SPA with UI components from Shadcn UI
2. **Backend (Server)**: Express.js server with RESTful API endpoints
3. **Database**: PostgreSQL using Drizzle ORM for data access

### Technology Stack

- **Frontend**: React, TypeScript, Tailwind CSS, Shadcn UI components
- **Backend**: Node.js, Express.js, TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Deployment**: Configured for deployment on Replit

## 3. Key Components

### 3.1 Frontend Architecture

The client-side application is built with React and organized as follows:

- `/client/src/` - Main source code directory
  - `/components/` - Reusable UI components
    - `/ui/` - Shadcn UI component library (based on Radix UI primitives)
    - Application-specific components (e.g., `DrugInteractionChecker`, `MedicineCard`)
  - `/hooks/` - Custom React hooks
  - `/lib/` - Utility functions, type definitions, and API client code
  - `/pages/` - Page components for each route

Key frontend architectural decisions:

1. **Component Library**: Uses Shadcn UI components based on Radix UI for accessibility and consistent styling
2. **State Management**: React Query for server state management and local React state for UI state
3. **Routing**: Uses Wouter for lightweight client-side routing
4. **Styling**: Tailwind CSS for utility-based styling with a design system using CSS variables

### 3.2 Backend Architecture

The server-side application is built with Express.js:

- `/server/` - Main server code directory
  - `index.ts` - Main entry point for the Express application
  - `routes.ts` - API route definitions
  - `/services/` - Business logic services organized by domain
    - `medicineService.ts` - Medicine-related operations
    - `symptomService.ts` - Symptom analysis logic
    - `locationService.ts` - Geographic services for nearby locations
    - `userService.ts` - User profile management

Key backend architectural decisions:

1. **API Design**: RESTful API with domain-driven service organization
2. **Middleware Pattern**: Express middleware for request logging, error handling, etc.
3. **Service Layer**: Business logic encapsulated in service modules

### 3.3 Database Schema

The application uses a PostgreSQL database with Drizzle ORM. Schema defined in `/shared/schema.ts`:

Key entities:
- **Users**: User profiles with health information
- **Medicines**: Medical products information
- **Symptoms/Conditions**: Health symptoms and related conditions
- **Medical Services**: Nearby healthcare providers

Key database architectural decisions:

1. **ORM**: Uses Drizzle ORM for type-safe database access
2. **Schema Organization**: Schema defined in a shared location to be used by both frontend and backend
3. **Relations**: Properly defined relations between tables using Drizzle relations

## 4. Data Flow

### 4.1 Frontend to Backend

1. Client makes HTTP requests to the server API endpoints
2. React Query manages request caching, loading states, and refetching
3. Requests are handled by the appropriate Express route handlers
4. Route handlers delegate to service modules for business logic
5. Services interact with the database through Drizzle ORM
6. Response data flows back to the client

### 4.2 Key API Endpoints

The application exposes several API endpoints organized by domain:

- `/api/medicines/*` - Medicine information and search
- `/api/symptoms/*` - Symptom analysis
- `/api/interactions/*` - Drug interaction checking
- `/api/services/nearby` - Nearby medical services
- `/api/user/*` - User profile management

## 5. External Dependencies

### 5.1 UI Components

- **Radix UI**: Provides primitive UI components
- **Shadcn UI**: Component library built on Radix UI
- **Tailwind CSS**: Utility-first CSS framework

### 5.2 State Management

- **React Query**: Data fetching and state management
- **React Hook Form**: Form state and validation

### 5.3 Database and ORM

- **Neon Database**: PostgreSQL database service (serverless)
- **Drizzle ORM**: Type-safe ORM for database access
- **Zod**: Schema validation for database models and API requests

### 5.4 External Services

- **Geolocation API**: Browser geolocation API for user location detection

## 6. Deployment Strategy

The application is configured for deployment on Replit:

1. **Development**: 
   - `npm run dev` starts the development server with hot reloading

2. **Production Build**:
   - Frontend assets built with Vite
   - Backend compiled with esbuild
   - Combined into a single distribution package

3. **Runtime Configuration**:
   - Environment variables used for database connection and other configuration
   - Replit-specific configuration in `.replit` file

4. **Database Migration**:
   - Drizzle Kit used for schema migrations
   - Scripts provided for seeding initial data

## 7. Authentication and Authorization

The application implements user authentication, likely using session-based auth with PostgreSQL session storage (connect-pg-simple package is included in dependencies).

User data is associated with user profiles, allowing for personalized experiences like saved medications and symptom checks.

## 8. Performance Considerations

1. **Client-side Caching**: React Query handles caching of API responses
2. **Bundle Optimization**: Vite is used for efficient frontend bundling
3. **Error Handling**: Runtime error overlays for better debugging