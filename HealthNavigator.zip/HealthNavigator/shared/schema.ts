import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// User tables
export const users = pgTable("users", {
  id: text("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  dateOfBirth: text("date_of_birth"),
  gender: text("gender"),
  phone: text("phone"),
  address: text("address"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const userAllergies = pgTable("user_allergies", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  allergyName: text("allergy_name").notNull()
});

export const userConditions = pgTable("user_conditions", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  conditionName: text("condition_name").notNull()
});

export const userMedications = pgTable("user_medications", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  medicineId: text("medicine_id").notNull().references(() => medicines.id),
  dosage: text("dosage"),
  frequency: text("frequency"),
  startDate: text("start_date"),
  endDate: text("end_date"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const userSymptomChecks = pgTable("user_symptom_checks", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  date: timestamp("date").defaultNow().notNull(),
  symptoms: jsonb("symptoms").$type<string[]>().notNull(),
  matchedConditions: jsonb("matched_conditions").$type<{
    id: string;
    name: string;
    matchPercentage: number;
    description?: string;
  }[]>().notNull()
});

// Medicine tables
export const medicines = pgTable("medicines", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  dosage: text("dosage").notNull(),
  form: text("form").notNull(),
  genericAvailable: boolean("generic_available").notNull(),
  prescriptionRequired: boolean("prescription_required").notNull(),
  uses: text("uses").notNull(),
  sideEffects: jsonb("side_effects").$type<{
    name: string;
    severity: "high" | "medium" | "low";
  }[]>().notNull(),
  imageUrl: text("image_url"),
  description: text("description"),
  mechanismOfAction: text("mechanism_of_action"),
  administration: text("administration"),
  missedDose: text("missed_dose"),
  contraindications: text("contraindications"),
  specialPopulations: text("special_populations"),
  genericAlternatives: jsonb("generic_alternatives").$type<string[]>(),
  brandAlternatives: jsonb("brand_alternatives").$type<string[]>()
});

export const popularMedicines = pgTable("popular_medicines", {
  id: text("id").primaryKey(),
  medicineId: text("medicine_id").notNull().references(() => medicines.id),
  rank: integer("rank").notNull()
});

export const drugInteractions = pgTable("drug_interactions", {
  id: text("id").primaryKey(),
  medicationA: text("medication_a").notNull(),
  medicationB: text("medication_b").notNull(),
  severity: text("severity").$type<"high" | "medium" | "low">().notNull(),
  description: text("description").notNull()
});

export const commonDrugInteractions = pgTable("common_drug_interactions", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  medicationA: text("medication_a").notNull(),
  medicationB: text("medication_b").notNull(),
  severity: text("severity").$type<"high" | "medium" | "low">().notNull(),
  description: text("description").notNull()
});

// Symptom and condition tables
export const symptoms = pgTable("symptoms", {
  id: text("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description")
});

export const conditions = pgTable("conditions", {
  id: text("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  totalSymptoms: integer("total_symptoms")
});

export const symptomConditionMap = pgTable("symptom_condition_map", {
  id: text("id").primaryKey(),
  symptomId: text("symptom_id").notNull().references(() => symptoms.id),
  conditionId: text("condition_id").notNull().references(() => conditions.id)
});

export const commonConditions = pgTable("common_conditions", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  conditionId: text("condition_id").notNull().references(() => conditions.id)
});

// Medical services table
export const medicalServices = pgTable("medical_services", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").$type<"hospital" | "clinic" | "pharmacy" | "urgent care">().notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull(),
  rating: numeric("rating").notNull(),
  openNow: boolean("open_now").notNull(),
  hoursToday: text("hours_today").notNull(),
  lat: numeric("lat").notNull(),
  lng: numeric("lng").notNull()
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  allergies: many(userAllergies),
  conditions: many(userConditions),
  medications: many(userMedications),
  symptomChecks: many(userSymptomChecks)
}));

export const userAllergiesRelations = relations(userAllergies, ({ one }) => ({
  user: one(users, {
    fields: [userAllergies.userId],
    references: [users.id]
  })
}));

export const userConditionsRelations = relations(userConditions, ({ one }) => ({
  user: one(users, {
    fields: [userConditions.userId],
    references: [users.id]
  })
}));

export const userMedicationsRelations = relations(userMedications, ({ one }) => ({
  user: one(users, {
    fields: [userMedications.userId],
    references: [users.id]
  }),
  medicine: one(medicines, {
    fields: [userMedications.medicineId],
    references: [medicines.id]
  })
}));

export const userSymptomChecksRelations = relations(userSymptomChecks, ({ one }) => ({
  user: one(users, {
    fields: [userSymptomChecks.userId],
    references: [users.id]
  })
}));

export const medicinesRelations = relations(medicines, ({ many }) => ({
  popularRanking: many(popularMedicines)
}));

export const popularMedicinesRelations = relations(popularMedicines, ({ one }) => ({
  medicine: one(medicines, {
    fields: [popularMedicines.medicineId],
    references: [medicines.id]
  })
}));

export const symptomsRelations = relations(symptoms, ({ many }) => ({
  conditionMaps: many(symptomConditionMap)
}));

export const conditionsRelations = relations(conditions, ({ many }) => ({
  symptomMaps: many(symptomConditionMap),
  commonCondition: many(commonConditions)
}));

export const symptomConditionMapRelations = relations(symptomConditionMap, ({ one }) => ({
  symptom: one(symptoms, {
    fields: [symptomConditionMap.symptomId],
    references: [symptoms.id]
  }),
  condition: one(conditions, {
    fields: [symptomConditionMap.conditionId],
    references: [conditions.id]
  })
}));

export const commonConditionsRelations = relations(commonConditions, ({ one }) => ({
  condition: one(conditions, {
    fields: [commonConditions.conditionId],
    references: [conditions.id]
  })
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  firstName: true,
  lastName: true,
  dateOfBirth: true,
  gender: true,
  phone: true,
  address: true
});

export const insertMedicineSchema = createInsertSchema(medicines, {
  sideEffects: () => z.array(z.object({
    name: z.string(),
    severity: z.enum(["high", "medium", "low"])
  })),
  genericAlternatives: () => z.array(z.string()).optional(),
  brandAlternatives: () => z.array(z.string()).optional()
});

export const insertSymptomSchema = createInsertSchema(symptoms);
export const insertConditionSchema = createInsertSchema(conditions);

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Medicine = typeof medicines.$inferSelect;
export type InsertMedicine = z.infer<typeof insertMedicineSchema>;

export type Symptom = typeof symptoms.$inferSelect;
export type InsertSymptom = z.infer<typeof insertSymptomSchema>;

export type Condition = typeof conditions.$inferSelect;
export type InsertCondition = z.infer<typeof insertConditionSchema>;

import { numeric } from "drizzle-orm/pg-core";
