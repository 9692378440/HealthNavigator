// Types for medicine information
export interface Medicine {
  id: string;
  name: string;
  category: string;
  dosage: string;
  form: string;
  genericAvailable: boolean;
  prescriptionRequired: boolean;
  uses: string;
  sideEffects: SideEffect[];
  imageUrl?: string;
  description?: string;
  mechanismOfAction?: string;
  administration?: string;
  missedDose?: string;
  contraindications?: string;
  specialPopulations?: string;
  genericAlternatives?: string[];
  brandAlternatives?: string[];
}

export interface SideEffect {
  name: string;
  severity: "high" | "medium" | "low";
}

// Types for search functionality
export interface SearchResult {
  id: string;
  title: string;
  type: "Disease" | "Symptom" | "Medication";
  description: string;
}

// Types for drug interactions
export interface Medication {
  id: string;
  name: string;
  category?: string;
}

export interface DrugInteraction {
  id: string;
  medications: string[];
  severity: "high" | "medium" | "low";
  description: string;
}

// Types for symptom checker
export interface Symptom {
  id: string;
  name: string;
  description?: string;
}

export interface ConditionMatch {
  id: string;
  name: string;
  matchPercentage: number;
  description?: string;
  symptoms?: string[];
}

// Types for nearby medical services
export interface MedicalService {
  id: string;
  name: string;
  type: "hospital" | "clinic" | "pharmacy" | "urgent care";
  distance: number;
  address: string;
  phone: string;
  rating: number;
  openNow: boolean;
  hoursToday: string;
  lat: number;
  lng: number;
}

// Types for user profile
export interface User {
  id: string;
  username: string;
  email: string;
  firstName?: string;
  lastName?: string;
  dateOfBirth?: string;
  gender?: string;
  phone?: string;
  address?: string;
  allergies?: string[];
  conditions?: string[];
  medications?: SavedMedication[];
  savedSymptomChecks?: SymptomCheck[];
}

export interface SavedMedication {
  id: string;
  medicineId: string;
  medicineName: string;
  dosage?: string;
  frequency?: string;
  startDate?: string;
  endDate?: string;
  notes?: string;
}

export interface SymptomCheck {
  id: string;
  date: string;
  symptoms: string[];
  conditions: ConditionMatch[];
}
