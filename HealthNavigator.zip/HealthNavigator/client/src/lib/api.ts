import { apiRequest } from "./queryClient";
import {
  Medicine,
  SearchResult,
  DrugInteraction,
  Symptom,
  ConditionMatch,
  MedicalService,
  User,
  SavedMedication,
  SymptomCheck
} from "./types";

// Medicine API functions
export async function fetchFeaturedMedicine(): Promise<Medicine> {
  const res = await apiRequest("GET", "/api/medicines/featured");
  return res.json();
}

export async function fetchMedicineById(id: string): Promise<Medicine> {
  const res = await apiRequest("GET", `/api/medicines/${id}`);
  return res.json();
}

export async function fetchPopularMedicines(): Promise<Medicine[]> {
  const res = await apiRequest("GET", "/api/medicines/popular");
  return res.json();
}

export async function searchMedicines(query: string): Promise<Medicine[]> {
  const res = await apiRequest("GET", `/api/medicines/search?q=${query}`);
  return res.json();
}

// Search API functions
export async function search(query: string): Promise<SearchResult[]> {
  const res = await apiRequest("GET", `/api/search?q=${query}`);
  return res.json();
}

// Drug interactions API functions
export async function checkDrugInteractions(medications: string[]): Promise<DrugInteraction[]> {
  const res = await apiRequest("POST", "/api/interactions/check", { medications });
  return res.json();
}

export async function fetchCommonInteractions(): Promise<DrugInteraction[]> {
  const res = await apiRequest("GET", "/api/interactions/common");
  return res.json();
}

// Symptom API functions
export async function searchSymptoms(query: string): Promise<Symptom[]> {
  const res = await apiRequest("GET", `/api/symptoms/search?q=${query}`);
  return res.json();
}

export async function analyzeSymptoms(symptoms: string[]): Promise<ConditionMatch[]> {
  const res = await apiRequest("POST", "/api/symptoms/analyze", { symptoms });
  return res.json();
}

export async function fetchCommonConditions(): Promise<{ name: string; symptoms: string[] }[]> {
  const res = await apiRequest("GET", "/api/conditions/common");
  return res.json();
}

// Medical services API functions
export async function findNearbyServices(
  lat: number,
  lng: number,
  radius: number,
  type?: string
): Promise<MedicalService[]> {
  const params = new URLSearchParams({
    lat: lat.toString(),
    lng: lng.toString(),
    radius: radius.toString(),
    ...(type && type !== "all" ? { type } : {})
  });
  
  const res = await apiRequest("GET", `/api/services/nearby?${params}`);
  return res.json();
}

// User profile API functions
export async function fetchUserProfile(): Promise<User> {
  const res = await apiRequest("GET", "/api/user/profile");
  return res.json();
}

export async function updateUserProfile(profileData: Partial<User>): Promise<User> {
  const res = await apiRequest("PATCH", "/api/user/profile", profileData);
  return res.json();
}

export async function saveMedicineToProfile(medicineId: string): Promise<{ success: boolean }> {
  const res = await apiRequest("POST", "/api/user/save-medicine", { medicineId });
  return res.json();
}

export async function saveMedication(medication: SavedMedication): Promise<SavedMedication> {
  const res = await apiRequest("POST", "/api/user/medications", medication);
  return res.json();
}

export async function updateMedication(medication: SavedMedication): Promise<SavedMedication> {
  const res = await apiRequest("PATCH", `/api/user/medications/${medication.id}`, medication);
  return res.json();
}

export async function deleteMedication(id: string): Promise<{ success: boolean }> {
  const res = await apiRequest("DELETE", `/api/user/medications/${id}`);
  return res.json();
}

export async function saveSymptomCheck(symptomCheck: Omit<SymptomCheck, "id">): Promise<SymptomCheck> {
  const res = await apiRequest("POST", "/api/user/symptom-checks", symptomCheck);
  return res.json();
}

export async function fetchSavedSymptomChecks(): Promise<SymptomCheck[]> {
  const res = await apiRequest("GET", "/api/user/symptom-checks");
  return res.json();
}
