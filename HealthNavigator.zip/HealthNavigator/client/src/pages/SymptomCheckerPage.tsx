import { useContext, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import SearchBar from "@/components/SearchBar";
import SymptomChecker from "@/components/SymptomChecker";
import { Card } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { SidebarContext } from "../App";

const SymptomCheckerPage = () => {
  const { setActiveItem } = useContext(SidebarContext);
  
  useEffect(() => {
    setActiveItem("symptom-checker");
  }, [setActiveItem]);

  // Query for common health conditions
  const { data: commonConditions } = useQuery<{ name: string; symptoms: string[] }[]>({
    queryKey: ['/api/conditions/common'],
  });

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Search Bar */}
      <SearchBar />
      
      <h1 className="text-2xl font-heading font-semibold mb-6">
        AI Symptom Checker
      </h1>
      
      <div className="mb-6 bg-primary bg-opacity-5 rounded-xl p-6">
        <div className="flex flex-col md:flex-row">
          <div className="w-full md:w-2/3 mb-4 md:mb-0 md:pr-6">
            <h2 className="text-xl font-heading font-semibold mb-3">How it works</h2>
            <p className="mb-4">
              Our AI-powered symptom checker uses advanced algorithms to analyze your symptoms and provide possible condition matches. It's a starting point for understanding your health concerns, not a replacement for professional medical advice.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
              <div className="flex items-start">
                <div className="w-8 h-8 rounded-full bg-primary bg-opacity-10 flex items-center justify-center mr-3 mt-1">
                  <i className="material-icons text-primary text-sm">add</i>
                </div>
                <div>
                  <h3 className="font-medium mb-1">Step 1</h3>
                  <p className="text-sm text-neutral-600">Enter your symptoms</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-8 h-8 rounded-full bg-primary bg-opacity-10 flex items-center justify-center mr-3 mt-1">
                  <i className="material-icons text-primary text-sm">psychology</i>
                </div>
                <div>
                  <h3 className="font-medium mb-1">Step 2</h3>
                  <p className="text-sm text-neutral-600">AI analyzes your symptoms</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-8 h-8 rounded-full bg-primary bg-opacity-10 flex items-center justify-center mr-3 mt-1">
                  <i className="material-icons text-primary text-sm">list</i>
                </div>
                <div>
                  <h3 className="font-medium mb-1">Step 3</h3>
                  <p className="text-sm text-neutral-600">Review possible conditions</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-8 h-8 rounded-full bg-primary bg-opacity-10 flex items-center justify-center mr-3 mt-1">
                  <i className="material-icons text-primary text-sm">health_and_safety</i>
                </div>
                <div>
                  <h3 className="font-medium mb-1">Step 4</h3>
                  <p className="text-sm text-neutral-600">Take appropriate action</p>
                </div>
              </div>
            </div>
          </div>
          <div className="w-full md:w-1/3">
            <Card className="p-4 bg-white shadow">
              <h3 className="font-heading font-medium mb-3 flex items-center">
                <i className="material-icons text-warning mr-2">warning</i>
                Important Notice
              </h3>
              <p className="text-sm text-neutral-600">
                This tool is for informational purposes only and does not provide medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition.
              </p>
              <div className="mt-4">
                <Button className="w-full">
                  <i className="material-icons mr-2">medical_services</i>
                  Find Medical Help
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
      
      {/* Symptom Checker */}
      <div className="mb-8">
        <SymptomChecker />
      </div>
      
      {/* Common Conditions */}
      {commonConditions && commonConditions.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-heading font-semibold mb-4">Common Health Conditions</h2>
          <Accordion type="single" collapsible className="bg-white rounded-xl shadow-md overflow-hidden">
            {commonConditions.map((condition, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="px-6 py-4 hover:bg-neutral-50">
                  {condition.name}
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4">
                  <h4 className="font-medium mb-2">Common Symptoms:</h4>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {condition.symptoms.map((symptom, idx) => (
                      <Badge 
                        key={idx} 
                        className="bg-neutral-100 text-neutral-700 rounded-full px-3 py-1"
                      >
                        {symptom}
                      </Badge>
                    ))}
                  </div>
                  <Button variant="outline" className="text-primary">
                    Learn More about {condition.name}
                  </Button>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      )}
      
      {/* FAQ Section */}
      <div className="mb-8">
        <h2 className="text-xl font-heading font-semibold mb-4">Frequently Asked Questions</h2>
        <Accordion type="single" collapsible className="bg-white rounded-xl shadow-md overflow-hidden">
          <AccordionItem value="faq-1">
            <AccordionTrigger className="px-6 py-4 hover:bg-neutral-50">
              How accurate is the symptom checker?
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-4">
              The symptom checker provides potential matches based on the symptoms you enter, but it's not a diagnostic tool. Its accuracy depends on the symptoms you provide and how well they match known patterns. Always consult a healthcare professional for proper diagnosis.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="faq-2">
            <AccordionTrigger className="px-6 py-4 hover:bg-neutral-50">
              Is my health data kept private?
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-4">
              Yes, we take data privacy seriously. Your symptom information and search history are encrypted and stored securely. We do not share your personal health information with third parties without your consent.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="faq-3">
            <AccordionTrigger className="px-6 py-4 hover:bg-neutral-50">
              What should I do if I have serious symptoms?
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-4">
              If you're experiencing severe symptoms such as chest pain, difficulty breathing, severe bleeding, or loss of consciousness, seek immediate medical attention by calling emergency services (911) or going to the nearest emergency room.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="faq-4">
            <AccordionTrigger className="px-6 py-4 hover:bg-neutral-50">
              Can I save my symptom check results?
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-4">
              Yes, if you have an account, you can save your symptom check results to your profile for future reference or to share with your healthcare provider during appointments.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </div>
  );
};

// Add missing imports
import { Badge } from "@/components/ui/badge";

export default SymptomCheckerPage;
