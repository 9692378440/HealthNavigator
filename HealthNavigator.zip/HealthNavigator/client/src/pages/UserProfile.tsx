import { useContext, useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import SearchBar from "@/components/SearchBar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { SidebarContext } from "../App";
import { useToast } from "@/hooks/use-toast";
import { SavedMedication, SymptomCheck } from "@/lib/types";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";

const UserProfile = () => {
  const { setActiveItem } = useContext(SidebarContext);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editMode, setEditMode] = useState(false);
  const [newAllergy, setNewAllergy] = useState("");
  const [newCondition, setNewCondition] = useState("");
  
  useEffect(() => {
    setActiveItem("profile");
  }, [setActiveItem]);

  // Fetch user profile
  const { 
    data: user, 
    isLoading: loadingUser,
    isError: userError
  } = useQuery({ 
    queryKey: ['/api/user/profile'],
  });

  // Update user profile mutation
  const updateProfile = useMutation({
    mutationFn: (userData: any) => 
      apiRequest("PATCH", "/api/user/profile", userData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      setEditMode(false);
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Update failed",
        description: "There was an error updating your profile. Please try again.",
        variant: "destructive",
      });
      console.error("Error updating profile:", error);
    }
  });

  // Mutations for allergies and conditions
  const addAllergy = useMutation({
    mutationFn: (allergy: string) => 
      apiRequest("POST", "/api/user/allergies", { allergy }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      setNewAllergy("");
      toast({
        title: "Allergy added",
        description: "Your allergy has been added to your profile.",
      });
    }
  });

  const removeAllergy = useMutation({
    mutationFn: (allergy: string) => 
      apiRequest("DELETE", `/api/user/allergies/${encodeURIComponent(allergy)}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      toast({
        title: "Allergy removed",
        description: "The allergy has been removed from your profile.",
      });
    }
  });

  const addCondition = useMutation({
    mutationFn: (condition: string) => 
      apiRequest("POST", "/api/user/conditions", { condition }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      setNewCondition("");
      toast({
        title: "Medical condition added",
        description: "Your medical condition has been added to your profile.",
      });
    }
  });

  const removeCondition = useMutation({
    mutationFn: (condition: string) => 
      apiRequest("DELETE", `/api/user/conditions/${encodeURIComponent(condition)}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      toast({
        title: "Condition removed",
        description: "The medical condition has been removed from your profile.",
      });
    }
  });

  // Delete medication mutation
  const deleteMedication = useMutation({
    mutationFn: (medicationId: string) => 
      apiRequest("DELETE", `/api/user/medications/${medicationId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      toast({
        title: "Medication removed",
        description: "The medication has been removed from your profile.",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) return;
    
    const form = e.target as HTMLFormElement;
    const updatedUser = {
      firstName: form.firstName.value,
      lastName: form.lastName.value,
      email: form.email.value,
      dateOfBirth: form.dateOfBirth.value,
      gender: form.gender.value,
      phone: form.phone.value,
      address: form.address.value,
    };
    
    updateProfile.mutate(updatedUser);
  };

  const handleAddAllergy = (e: React.FormEvent) => {
    e.preventDefault();
    if (newAllergy.trim()) {
      addAllergy.mutate(newAllergy.trim());
    }
  };

  const handleAddCondition = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCondition.trim()) {
      addCondition.mutate(newCondition.trim());
    }
  };

  if (loadingUser) {
    return (
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-center items-center min-h-[60vh]">
          <div className="text-center">
            <i className="material-icons animate-spin text-4xl mb-2">refresh</i>
            <p>Loading your profile...</p>
          </div>
        </div>
      </div>
    );
  }

  if (userError) {
    return (
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-center items-center min-h-[60vh]">
          <Card className="w-full max-w-md">
            <CardContent className="pt-6">
              <div className="text-center">
                <i className="material-icons text-danger text-4xl mb-2">error_outline</i>
                <h2 className="text-xl font-heading font-semibold mb-2">Failed to Load Profile</h2>
                <p className="text-neutral-600 mb-4">
                  We couldn't load your profile information. Please try again later.
                </p>
                <Button 
                  onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] })}
                >
                  Retry
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Search Bar */}
      <SearchBar />
      
      <h1 className="text-2xl font-heading font-semibold mb-6">
        My Profile
      </h1>
      
      <Tabs defaultValue="personal" className="mb-6">
        <TabsList className="mb-6">
          <TabsTrigger value="personal">
            <i className="material-icons mr-2">person</i> Personal Info
          </TabsTrigger>
          <TabsTrigger value="health">
            <i className="material-icons mr-2">medical_information</i> Health Information
          </TabsTrigger>
          <TabsTrigger value="medications">
            <i className="material-icons mr-2">medication</i> My Medications
          </TabsTrigger>
          <TabsTrigger value="history">
            <i className="material-icons mr-2">history</i> Health History
          </TabsTrigger>
        </TabsList>
        
        {/* Personal Information Tab */}
        <TabsContent value="personal">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Personal Information</CardTitle>
              <Button
                variant={editMode ? "default" : "outline"}
                onClick={() => setEditMode(!editMode)}
              >
                <i className="material-icons mr-2">{editMode ? "save" : "edit"}</i>
                {editMode ? "Save" : "Edit"} Profile
              </Button>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <label className="block text-sm font-medium mb-1">First Name</label>
                    <Input
                      id="firstName"
                      name="firstName"
                      defaultValue={user?.firstName || ""}
                      disabled={!editMode}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Last Name</label>
                    <Input
                      id="lastName"
                      name="lastName"
                      defaultValue={user?.lastName || ""}
                      disabled={!editMode}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Email</label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      defaultValue={user?.email || ""}
                      disabled={!editMode}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Date of Birth</label>
                    <Input
                      id="dateOfBirth"
                      name="dateOfBirth"
                      type="date"
                      defaultValue={user?.dateOfBirth || ""}
                      disabled={!editMode}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Gender</label>
                    <select
                      id="gender"
                      name="gender"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      defaultValue={user?.gender || ""}
                      disabled={!editMode}
                    >
                      <option value="">Select Gender</option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                      <option value="other">Other</option>
                      <option value="prefer_not_to_say">Prefer not to say</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Phone Number</label>
                    <Input
                      id="phone"
                      name="phone"
                      type="tel"
                      defaultValue={user?.phone || ""}
                      disabled={!editMode}
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium mb-1">Address</label>
                    <Textarea
                      id="address"
                      name="address"
                      defaultValue={user?.address || ""}
                      disabled={!editMode}
                      rows={3}
                    />
                  </div>
                </div>
                {editMode && (
                  <div className="flex justify-end">
                    <Button type="button" variant="outline" className="mr-2" onClick={() => setEditMode(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={updateProfile.isPending}>
                      {updateProfile.isPending ? (
                        <>
                          <i className="material-icons animate-spin mr-2">refresh</i>
                          Saving...
                        </>
                      ) : (
                        <>
                          <i className="material-icons mr-2">save</i>
                          Save Changes
                        </>
                      )}
                    </Button>
                  </div>
                )}
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Health Information Tab */}
        <TabsContent value="health">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Allergies */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="material-icons mr-2 text-danger">warning</i>
                  Allergies
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  {user?.allergies && user.allergies.length > 0 ? (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {user.allergies.map((allergy, index) => (
                        <Badge
                          key={index}
                          variant="outline"
                          className="bg-danger bg-opacity-10 text-danger rounded-full px-3 py-1 flex items-center"
                        >
                          {allergy}
                          <button
                            className="ml-1 text-danger hover:text-danger"
                            onClick={() => removeAllergy.mutate(allergy)}
                          >
                            <i className="material-icons text-sm">close</i>
                          </button>
                        </Badge>
                      ))}
                    </div>
                  ) : (
                    <p className="text-neutral-500 mb-4">No allergies recorded.</p>
                  )}
                  
                  <form onSubmit={handleAddAllergy} className="flex gap-2">
                    <Input
                      placeholder="Add new allergy"
                      value={newAllergy}
                      onChange={(e) => setNewAllergy(e.target.value)}
                    />
                    <Button type="submit" disabled={!newAllergy.trim() || addAllergy.isPending}>
                      <i className="material-icons">add</i>
                    </Button>
                  </form>
                </div>
              </CardContent>
            </Card>
            
            {/* Medical Conditions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="material-icons mr-2 text-primary">sick</i>
                  Medical Conditions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  {user?.conditions && user.conditions.length > 0 ? (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {user.conditions.map((condition, index) => (
                        <Badge
                          key={index}
                          variant="outline"
                          className="bg-primary bg-opacity-10 text-primary rounded-full px-3 py-1 flex items-center"
                        >
                          {condition}
                          <button
                            className="ml-1 text-primary hover:text-primary-dark"
                            onClick={() => removeCondition.mutate(condition)}
                          >
                            <i className="material-icons text-sm">close</i>
                          </button>
                        </Badge>
                      ))}
                    </div>
                  ) : (
                    <p className="text-neutral-500 mb-4">No medical conditions recorded.</p>
                  )}
                  
                  <form onSubmit={handleAddCondition} className="flex gap-2">
                    <Input
                      placeholder="Add medical condition"
                      value={newCondition}
                      onChange={(e) => setNewCondition(e.target.value)}
                    />
                    <Button type="submit" disabled={!newCondition.trim() || addCondition.isPending}>
                      <i className="material-icons">add</i>
                    </Button>
                  </form>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* Medications Tab */}
        <TabsContent value="medications">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>My Medications</CardTitle>
              <Dialog>
                <DialogTrigger asChild>
                  <Button>
                    <i className="material-icons mr-2">add</i>
                    Add Medication
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Medication</DialogTitle>
                  </DialogHeader>
                  <MedicationForm />
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {user?.medications && user.medications.length > 0 ? (
                <div className="space-y-4">
                  {user.medications.map((medication: SavedMedication) => (
                    <div key={medication.id} className="border rounded-lg p-4 hover:bg-neutral-50">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-medium">{medication.medicineName}</h3>
                          <p className="text-sm text-neutral-500">
                            {medication.dosage} {medication.frequency && `• ${medication.frequency}`}
                          </p>
                          {medication.startDate && (
                            <p className="text-xs text-neutral-500">
                              Started: {format(new Date(medication.startDate), 'MMM d, yyyy')}
                              {medication.endDate && ` • Ends: ${format(new Date(medication.endDate), 'MMM d, yyyy')}`}
                            </p>
                          )}
                          {medication.notes && (
                            <p className="text-sm text-neutral-600 mt-2">{medication.notes}</p>
                          )}
                        </div>
                        <div className="flex space-x-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm">
                                <i className="material-icons text-sm">edit</i>
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Edit Medication</DialogTitle>
                              </DialogHeader>
                              <MedicationForm medication={medication} />
                            </DialogContent>
                          </Dialog>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="text-danger"
                            onClick={() => deleteMedication.mutate(medication.id)}
                          >
                            <i className="material-icons text-sm">delete</i>
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <i className="material-icons text-neutral-400 text-4xl mb-2">medication</i>
                  <p className="text-neutral-600">You haven't added any medications yet.</p>
                  <p className="text-sm text-neutral-500 mt-1">
                    Add your current medications to keep track of them and check for interactions.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Health History Tab */}
        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Symptom Check History</CardTitle>
            </CardHeader>
            <CardContent>
              {user?.savedSymptomChecks && user.savedSymptomChecks.length > 0 ? (
                <div className="space-y-4">
                  {user.savedSymptomChecks.map((check: SymptomCheck) => (
                    <div key={check.id} className="border rounded-lg p-4 hover:bg-neutral-50">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-medium">Symptom Check on {format(new Date(check.date), 'MMM d, yyyy')}</h3>
                        <Badge className="bg-primary text-white">
                          {check.conditions.length} conditions
                        </Badge>
                      </div>
                      
                      <div className="mb-3">
                        <h4 className="text-sm font-medium mb-1">Symptoms:</h4>
                        <div className="flex flex-wrap gap-2">
                          {check.symptoms.map((symptom, idx) => (
                            <Badge key={idx} variant="outline" className="bg-neutral-100">
                              {symptom}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium mb-1">Possible Conditions:</h4>
                        <div className="space-y-2">
                          {check.conditions.map((condition, idx) => (
                            <div key={idx} className="flex items-center justify-between text-sm">
                              <span>{condition.name}</span>
                              <div className="flex items-center">
                                <div className="w-16 bg-neutral-200 rounded-full h-2 mr-2">
                                  <div 
                                    className={`${
                                      condition.matchPercentage >= 75 ? "bg-primary" : 
                                      condition.matchPercentage >= 50 ? "bg-warning" : 
                                      "bg-neutral-400"
                                    } rounded-full h-2`} 
                                    style={{ width: `${condition.matchPercentage}%` }}
                                  ></div>
                                </div>
                                <span className="text-xs">{condition.matchPercentage}%</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <i className="material-icons text-neutral-400 text-4xl mb-2">search</i>
                  <p className="text-neutral-600">No symptom check history found.</p>
                  <p className="text-sm text-neutral-500 mt-1">
                    When you use the symptom checker, you can save your results for future reference.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

// Medication Form Component for adding/editing medications
const MedicationForm = ({ medication }: { medication?: SavedMedication }) => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    id: medication?.id || "",
    medicineId: medication?.medicineId || "",
    medicineName: medication?.medicineName || "",
    dosage: medication?.dosage || "",
    frequency: medication?.frequency || "",
    startDate: medication?.startDate || "",
    endDate: medication?.endDate || "",
    notes: medication?.notes || "",
  });
  
  const { data: searchResults, isLoading: searchingMedicines } = useQuery({
    queryKey: ['/api/medicines/search', formData.medicineName],
    enabled: formData.medicineName.length >= 2 && !medication,
  });
  
  const saveMedication = useMutation({
    mutationFn: (data: SavedMedication) => 
      apiRequest(
        data.id ? "PATCH" : "POST", 
        data.id ? `/api/user/medications/${data.id}` : "/api/user/medications", 
        data
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      toast({
        title: medication ? "Medication updated" : "Medication added",
        description: medication 
          ? "Your medication has been updated successfully."
          : "Your medication has been added to your profile.",
      });
    },
    onError: (error) => {
      toast({
        title: "Operation failed",
        description: "There was an error saving your medication. Please try again.",
        variant: "destructive",
      });
      console.error("Error saving medication:", error);
    }
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveMedication.mutate(formData);
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4 mt-4">
      <div>
        <label className="block text-sm font-medium mb-1">Medication Name*</label>
        {medication ? (
          <Input
            name="medicineName"
            value={formData.medicineName}
            onChange={handleChange}
            required
            disabled
          />
        ) : (
          <div className="relative">
            <Input
              name="medicineName"
              value={formData.medicineName}
              onChange={handleChange}
              placeholder="Start typing to search..."
              required
            />
            {formData.medicineName.length >= 2 && searchResults && searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 z-10 bg-white shadow-lg rounded-md mt-1 max-h-48 overflow-y-auto">
                {searchResults.map((medicine: any, idx) => (
                  <div
                    key={idx}
                    className="p-2 hover:bg-neutral-100 cursor-pointer"
                    onClick={() => setFormData(prev => ({
                      ...prev,
                      medicineId: medicine.id,
                      medicineName: medicine.name
                    }))}
                  >
                    {medicine.name}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Dosage</label>
          <Input
            name="dosage"
            value={formData.dosage}
            onChange={handleChange}
            placeholder="e.g., 10mg"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Frequency</label>
          <Input
            name="frequency"
            value={formData.frequency}
            onChange={handleChange}
            placeholder="e.g., Once daily"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Start Date</label>
          <Input
            type="date"
            name="startDate"
            value={formData.startDate}
            onChange={handleChange}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">End Date</label>
          <Input
            type="date"
            name="endDate"
            value={formData.endDate}
            onChange={handleChange}
          />
        </div>
      </div>
      
      <div>
        <label className="block text-sm font-medium mb-1">Notes</label>
        <Textarea
          name="notes"
          value={formData.notes}
          onChange={handleChange}
          placeholder="Any additional information..."
          rows={3}
        />
      </div>
      
      <div className="flex justify-end space-x-2 pt-2">
        <DialogTrigger asChild>
          <Button type="button" variant="outline">Cancel</Button>
        </DialogTrigger>
        <Button type="submit" disabled={saveMedication.isPending}>
          {saveMedication.isPending ? (
            <>
              <i className="material-icons animate-spin mr-2">refresh</i>
              Saving...
            </>
          ) : (
            <>
              <i className="material-icons mr-2">save</i>
              {medication ? "Update" : "Save"} Medication
            </>
          )}
        </Button>
      </div>
    </form>
  );
};

export default UserProfile;
