import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

interface ConditionDetail {
  id: string;
  name: string;
  description: string;
  symptoms: string[];
  prevalence?: string;
  treatment?: string;
  prevention?: string;
  riskFactors?: string[];
  relatedConditions?: string[];
}

const ConditionInfoPage = () => {
  const { id } = useParams<{ id: string }>();
  const [condition, setCondition] = useState<ConditionDetail | null>(null);

  // Fetch condition data
  const { data: conditionData, isLoading, error } = useQuery({
    queryKey: ['/api/conditions', id],
    queryFn: async () => {
      const response = await fetch(`/api/conditions/${id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch condition details');
      }
      return response.json();
    },
    enabled: !!id
  });

  useEffect(() => {
    if (conditionData) {
      setCondition(conditionData);
    }
  }, [conditionData]);

  // Fallback data for testing purposes
  useEffect(() => {
    if (error) {
      console.error("Error fetching condition:", error);
      // Temporary data for demonstration purposes
      if (id === '1') {
        setCondition({
          id: '1',
          name: 'Hypertension',
          description: 'High blood pressure is a common condition in which the long-term force of the blood against your artery walls is high enough that it may eventually cause health problems, such as heart disease.',
          symptoms: ['Headache', 'Shortness of breath', 'Nosebleeds', 'Dizziness'],
          prevalence: 'Approximately 1 in 3 adults worldwide',
          treatment: 'Lifestyle changes, medication such as ACE inhibitors, diuretics, or beta-blockers',
          prevention: 'Regular exercise, healthy diet, reduced salt intake, limiting alcohol, not smoking',
          riskFactors: ['Obesity', 'Family history', 'Age', 'Race', 'Stress', 'Certain chronic conditions'],
          relatedConditions: ['Heart disease', 'Stroke', 'Kidney disease']
        });
      } else if (id === '2') {
        setCondition({
          id: '2',
          name: 'Diabetes Type 2',
          description: 'Type 2 diabetes is a chronic condition that affects the way your body metabolizes sugar (glucose). With type 2 diabetes, your body either resists the effects of insulin or doesn\'t produce enough insulin to maintain normal glucose levels.',
          symptoms: ['Increased thirst', 'Frequent urination', 'Increased hunger', 'Fatigue', 'Blurred vision'],
          prevalence: 'Affects approximately 462 million people worldwide',
          treatment: 'Healthy eating, regular exercise, maintaining a normal weight, monitoring blood sugar, diabetes medications or insulin therapy',
          prevention: 'Eat healthy foods, get active, lose excess weight',
          riskFactors: ['Weight', 'Fat distribution', 'Inactivity', 'Family history', 'Age', 'Prediabetes'],
          relatedConditions: ['Heart and blood vessel disease', 'Nerve damage', 'Kidney damage', 'Eye damage']
        });
      } else {
        setCondition({
          id: id || 'unknown',
          name: 'Condition Information',
          description: 'Detailed information about this condition is currently being updated.',
          symptoms: ['Contact a healthcare professional for specific symptom information'],
          prevalence: 'Data being updated',
          treatment: 'Consult with a healthcare professional for treatment options',
          prevention: 'Consult with a healthcare professional for prevention guidelines',
          riskFactors: ['Consult with a healthcare professional for risk factor information'],
          relatedConditions: []
        });
      }
    }
  }, [error, id]);

  const renderSymptomBadges = (symptoms: string[]) => {
    return symptoms.map((symptom, index) => (
      <Badge 
        key={index} 
        className="bg-neutral-100 hover:bg-neutral-200 text-neutral-700 rounded-full px-3 py-1 mr-2 mb-2"
      >
        {symptom}
      </Badge>
    ));
  };

  if (isLoading) {
    return (
      <div className="container max-w-4xl mx-auto py-8 px-4">
        <div className="flex justify-center items-center h-64">
          <div className="text-center">
            <i className="material-icons animate-spin text-3xl text-primary mb-2">refresh</i>
            <p>Loading condition information...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      {condition ? (
        <>
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-heading font-bold">{condition.name}</h1>
              <p className="text-neutral-500 mt-1">Medical Condition</p>
            </div>
            <div className="mt-4 md:mt-0">
              <Button variant="outline" className="mr-2">
                <i className="material-icons mr-1">bookmark</i>
                Save
              </Button>
              <Button>
                <i className="material-icons mr-1">share</i>
                Share
              </Button>
            </div>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-neutral-700 mb-6">{condition.description}</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-heading font-semibold mb-2">Prevalence</h3>
                  <p className="text-neutral-700">{condition.prevalence}</p>
                </div>
                <div>
                  <h3 className="font-heading font-semibold mb-2">Related Conditions</h3>
                  <ul className="list-disc list-inside text-neutral-700">
                    {condition.relatedConditions && condition.relatedConditions.map((related, index) => (
                      <li key={index}>{related}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Symptoms</CardTitle>
              <CardDescription>Common signs and symptoms associated with {condition.name}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap">
                {renderSymptomBadges(condition.symptoms)}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Treatment</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-neutral-700">{condition.treatment}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Prevention</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-neutral-700">{condition.prevention}</p>
              </CardContent>
            </Card>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Risk Factors</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="list-disc list-inside text-neutral-700">
                {condition.riskFactors && condition.riskFactors.map((factor, index) => (
                  <li key={index} className="mb-1">{factor}</li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <div className="text-center mt-8 bg-neutral-50 p-6 rounded-lg">
            <h3 className="text-xl font-heading font-semibold mb-2">Need professional medical advice?</h3>
            <p className="text-neutral-600 mb-4">This information is for educational purposes only. Always consult with a healthcare professional.</p>
            <Button className="bg-primary text-white">
              <i className="material-icons mr-2">local_hospital</i>
              Find Healthcare Providers
            </Button>
          </div>
        </>
      ) : (
        <div className="flex justify-center items-center h-64">
          <div className="text-center">
            <i className="material-icons text-6xl text-neutral-300 mb-4">error_outline</i>
            <h2 className="text-2xl font-heading font-semibold mb-2">Condition Not Found</h2>
            <p className="text-neutral-500 mb-6">We couldn't find information about this condition.</p>
            <Link href="/">
              <Button>
                <i className="material-icons mr-2">home</i>
                Return to Home
              </Button>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConditionInfoPage;