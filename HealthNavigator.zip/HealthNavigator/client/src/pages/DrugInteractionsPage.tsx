import { useContext, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import SearchBar from "@/components/SearchBar";
import DrugInteractionChecker from "@/components/DrugInteractionChecker";
import { Card } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { SidebarContext } from "../App";

const DrugInteractionsPage = () => {
  const { setActiveItem } = useContext(SidebarContext);
  const [location] = useLocation();
  
  // Extract medication from query params if present
  const getQueryParams = () => {
    const params = new URLSearchParams(location.split('?')[1]);
    return {
      medication: params.get('medication')
    };
  };
  
  const { medication } = getQueryParams();
  
  // Set initial medications based on query param
  const initialMedications = medication ? [medication] : [];
  
  useEffect(() => {
    setActiveItem("drug-interactions");
  }, [setActiveItem]);

  // Query for common drug interactions
  const { data: commonInteractions } = useQuery<{
    name: string;
    medications: string[];
    severity: string;
    description: string;
  }[]>({
    queryKey: ['/api/interactions/common'],
  });

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Search Bar */}
      <SearchBar />
      
      <h1 className="text-2xl font-heading font-semibold mb-6">
        Drug Interaction Checker
      </h1>
      
      <div className="mb-6 bg-primary bg-opacity-5 rounded-xl p-6">
        <div className="flex flex-col md:flex-row">
          <div className="w-full md:w-2/3 mb-4 md:mb-0 md:pr-6">
            <h2 className="text-xl font-heading font-semibold mb-3">Why Check Drug Interactions?</h2>
            <p className="mb-4">
              Some medications can interact with each other, causing unexpected side effects or reducing effectiveness. Our drug interaction checker helps identify potential issues with your medications, including prescription drugs, over-the-counter medicines, and supplements.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-start">
                <div className="w-8 h-8 rounded-full bg-danger bg-opacity-10 flex items-center justify-center mr-3 mt-1">
                  <i className="material-icons text-danger text-sm">warning</i>
                </div>
                <div>
                  <h3 className="font-medium mb-1">Major Interactions</h3>
                  <p className="text-sm text-neutral-600">Highly clinically significant. Avoid combinations.</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-8 h-8 rounded-full bg-warning bg-opacity-10 flex items-center justify-center mr-3 mt-1">
                  <i className="material-icons text-warning text-sm">error_outline</i>
                </div>
                <div>
                  <h3 className="font-medium mb-1">Moderate Interactions</h3>
                  <p className="text-sm text-neutral-600">Moderately significant. Monitor closely.</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-8 h-8 rounded-full bg-success bg-opacity-10 flex items-center justify-center mr-3 mt-1">
                  <i className="material-icons text-success text-sm">info_outline</i>
                </div>
                <div>
                  <h3 className="font-medium mb-1">Minor Interactions</h3>
                  <p className="text-sm text-neutral-600">Minimally significant. Be aware of potential effects.</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-8 h-8 rounded-full bg-neutral-200 flex items-center justify-center mr-3 mt-1">
                  <i className="material-icons text-neutral-500 text-sm">check_circle</i>
                </div>
                <div>
                  <h3 className="font-medium mb-1">No Known Interactions</h3>
                  <p className="text-sm text-neutral-600">No significant interactions found.</p>
                </div>
              </div>
            </div>
          </div>
          <div className="w-full md:w-1/3">
            <Card className="p-4 bg-white shadow">
              <h3 className="font-heading font-medium mb-3 flex items-center">
                <i className="material-icons text-primary mr-2">tips_and_updates</i>
                Tips for Medication Safety
              </h3>
              <ul className="text-sm text-neutral-600 space-y-2">
                <li className="flex items-start">
                  <i className="material-icons text-primary text-sm mr-2 mt-0.5">check</i>
                  Keep a list of all your medications, including over-the-counter drugs and supplements
                </li>
                <li className="flex items-start">
                  <i className="material-icons text-primary text-sm mr-2 mt-0.5">check</i>
                  Use one pharmacy for all prescriptions when possible
                </li>
                <li className="flex items-start">
                  <i className="material-icons text-primary text-sm mr-2 mt-0.5">check</i>
                  Inform all your healthcare providers about your medications
                </li>
                <li className="flex items-start">
                  <i className="material-icons text-primary text-sm mr-2 mt-0.5">check</i>
                  Read medication labels and follow instructions carefully
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </div>
      
      {/* Drug Interaction Checker */}
      <div className="mb-8">
        <DrugInteractionChecker initialMedications={initialMedications} />
      </div>
      
      {/* Common Drug Interactions */}
      {commonInteractions && commonInteractions.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-heading font-semibold mb-4">Common Drug Interactions</h2>
          <Accordion type="single" collapsible className="bg-white rounded-xl shadow-md overflow-hidden">
            {commonInteractions.map((interaction, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="px-6 py-4 hover:bg-neutral-50">
                  <div className="flex items-center">
                    <div className={`w-2 h-2 rounded-full mr-2 ${
                      interaction.severity === "high" 
                        ? "bg-danger" 
                        : interaction.severity === "medium"
                        ? "bg-warning"
                        : "bg-success"
                    }`}></div>
                    {interaction.medications.join(" + ")}
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4">
                  <div className={`p-3 rounded-lg mb-3 ${
                    interaction.severity === "high" 
                      ? "bg-danger bg-opacity-10" 
                      : interaction.severity === "medium"
                      ? "bg-warning bg-opacity-10"
                      : "bg-success bg-opacity-10"
                  }`}>
                    <div className="flex items-center mb-2">
                      <i className={`material-icons mr-2 ${
                        interaction.severity === "high" 
                          ? "text-danger" 
                          : interaction.severity === "medium"
                          ? "text-warning"
                          : "text-success"
                      }`}>
                        {interaction.severity === "high" 
                          ? "warning" 
                          : interaction.severity === "medium"
                          ? "error_outline"
                          : "info_outline"
                        }
                      </i>
                      <h4 className="font-medium">
                        {interaction.severity === "high" 
                          ? "Major" 
                          : interaction.severity === "medium"
                          ? "Moderate"
                          : "Minor"
                        } Interaction
                      </h4>
                    </div>
                    <p className="text-sm">{interaction.description}</p>
                  </div>
                  <p className="text-sm text-neutral-600 mb-3">
                    <strong>Medications involved:</strong> {interaction.medications.join(", ")}
                  </p>
                  <p className="text-sm text-neutral-600">
                    <strong>What to do:</strong> {
                      interaction.severity === "high"
                        ? "Avoid using these medications together. Consult your doctor immediately if you are taking both."
                        : interaction.severity === "medium"
                        ? "Use with caution. Monitor for side effects and consult your doctor about potential risks."
                        : "Be aware of this interaction. Watch for changes in how you feel and inform your doctor if concerned."
                    }
                  </p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      )}
      
      {/* FAQ Section */}
      <div className="mb-8">
        <h2 className="text-xl font-heading font-semibold mb-4">Frequently Asked Questions</h2>
        <Accordion type="single" collapsible className="bg-white rounded-xl shadow-md overflow-hidden">
          <AccordionItem value="faq-1">
            <AccordionTrigger className="px-6 py-4 hover:bg-neutral-50">
              What types of drug interactions exist?
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-4">
              <p className="mb-2">There are several types of drug interactions:</p>
              <ul className="list-disc pl-5 text-sm text-neutral-600 space-y-1">
                <li><strong>Drug-drug interactions:</strong> When two or more medications interact with each other</li>
                <li><strong>Drug-food interactions:</strong> When medications interact with food or beverages</li>
                <li><strong>Drug-disease interactions:</strong> When a medication affects an existing medical condition</li>
                <li><strong>Drug-supplement interactions:</strong> When medications interact with vitamins, minerals, or herbal supplements</li>
              </ul>
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="faq-2">
            <AccordionTrigger className="px-6 py-4 hover:bg-neutral-50">
              Should I include over-the-counter medicines in the checker?
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-4">
              Yes, absolutely. Over-the-counter medications can interact with prescription drugs just like other medications. Common OTC products like pain relievers (ibuprofen, aspirin), antihistamines, acid reducers, and herbal supplements should all be included when checking for potential interactions.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="faq-3">
            <AccordionTrigger className="px-6 py-4 hover:bg-neutral-50">
              What should I do if I discover a potential interaction?
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-4">
              If you discover a potential interaction between medications you're taking:
              <ol className="list-decimal pl-5 text-sm text-neutral-600 space-y-1 mt-2">
                <li>Don't stop taking your medications without consulting a healthcare professional</li>
                <li>Contact your doctor or pharmacist promptly to discuss the potential interaction</li>
                <li>Ask about alternative medications that might not interact</li>
                <li>In case of severe interactions, seek medical advice immediately</li>
              </ol>
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="faq-4">
            <AccordionTrigger className="px-6 py-4 hover:bg-neutral-50">
              How often should I check for drug interactions?
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-4">
              You should check for potential drug interactions whenever there's a change in your medication regimen, including:
              <ul className="list-disc pl-5 text-sm text-neutral-600 space-y-1 mt-2">
                <li>When you're prescribed a new medication</li>
                <li>If you start taking a new over-the-counter drug or supplement</li>
                <li>When your dosage changes significantly</li>
                <li>If you see multiple healthcare providers who prescribe medications</li>
                <li>At least once yearly as a general review</li>
              </ul>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </div>
  );
};

export default DrugInteractionsPage;
