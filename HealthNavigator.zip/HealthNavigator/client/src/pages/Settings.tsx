import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

const Settings = () => {
  const { toast } = useToast();
  
  // Display settings
  const [darkMode, setDarkMode] = useState(false);
  const [fontSize, setFontSize] = useState("medium");
  const [colorTheme, setColorTheme] = useState("default");
  
  // Notification settings
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(true);
  const [reminderFrequency, setReminderFrequency] = useState("daily");
  
  // Privacy settings
  const [shareLocation, setShareLocation] = useState(true);
  const [saveSearchHistory, setSaveSearchHistory] = useState(true);
  const [dataCollection, setDataCollection] = useState("minimal");
  
  // Unit settings
  const [unitSystem, setUnitSystem] = useState("metric");
  const [temperature, setTemperature] = useState("celsius");
  
  // Accessibility settings
  const [textToSpeech, setTextToSpeech] = useState(false);
  const [contrastMode, setContrastMode] = useState(false);
  const [animationReduced, setAnimationReduced] = useState(false);
  
  const handleSave = () => {
    // In a real app, this would save settings to the server
    toast({
      title: "Settings saved successfully",
      description: "Your preferences have been updated.",
      variant: "default",
    });
  };
  
  const handleReset = () => {
    // Reset to defaults
    setDarkMode(false);
    setFontSize("medium");
    setColorTheme("default");
    setEmailNotifications(true);
    setPushNotifications(true);
    setReminderFrequency("daily");
    setShareLocation(true);
    setSaveSearchHistory(true);
    setDataCollection("minimal");
    setUnitSystem("metric");
    setTemperature("celsius");
    setTextToSpeech(false);
    setContrastMode(false);
    setAnimationReduced(false);
    
    toast({
      title: "Settings reset to defaults",
      description: "All preferences have been reset to their default values.",
      variant: "default",
    });
  };
  
  return (
    <div className="container max-w-4xl mx-auto py-6 px-4">
      <h1 className="text-3xl font-heading font-bold mb-6">Settings</h1>
      
      <Tabs defaultValue="display" className="w-full">
        <TabsList className="grid grid-cols-5 mb-6">
          <TabsTrigger value="display">Display</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="privacy">Privacy</TabsTrigger>
          <TabsTrigger value="units">Units</TabsTrigger>
          <TabsTrigger value="accessibility">Accessibility</TabsTrigger>
        </TabsList>
        
        <Card className="mb-6">
          <TabsContent value="display" className="p-6">
            <h2 className="text-xl font-heading font-semibold mb-4">Display Settings</h2>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="dark-mode" className="font-medium">Dark Mode</Label>
                  <p className="text-sm text-neutral-500">Enable dark theme throughout the app</p>
                </div>
                <Switch 
                  id="dark-mode" 
                  checked={darkMode} 
                  onCheckedChange={setDarkMode} 
                />
              </div>
              
              <Separator />
              
              <div>
                <Label htmlFor="font-size" className="font-medium block mb-2">Font Size</Label>
                <Select value={fontSize} onValueChange={setFontSize}>
                  <SelectTrigger id="font-size" className="w-full md:w-64">
                    <SelectValue placeholder="Select font size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="small">Small</SelectItem>
                    <SelectItem value="medium">Medium (Default)</SelectItem>
                    <SelectItem value="large">Large</SelectItem>
                    <SelectItem value="x-large">Extra Large</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Separator />
              
              <div>
                <Label className="font-medium block mb-2">Color Theme</Label>
                <RadioGroup value={colorTheme} onValueChange={setColorTheme} className="flex flex-col space-y-1">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="default" id="default-theme" />
                    <Label htmlFor="default-theme">Default Blue</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="green" id="green-theme" />
                    <Label htmlFor="green-theme">Forest Green</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="purple" id="purple-theme" />
                    <Label htmlFor="purple-theme">Royal Purple</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="red" id="red-theme" />
                    <Label htmlFor="red-theme">Ruby Red</Label>
                  </div>
                </RadioGroup>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="notifications" className="p-6">
            <h2 className="text-xl font-heading font-semibold mb-4">Notification Settings</h2>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="email-notifications" className="font-medium">Email Notifications</Label>
                  <p className="text-sm text-neutral-500">Receive important updates via email</p>
                </div>
                <Switch 
                  id="email-notifications" 
                  checked={emailNotifications} 
                  onCheckedChange={setEmailNotifications} 
                />
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="push-notifications" className="font-medium">Push Notifications</Label>
                  <p className="text-sm text-neutral-500">Receive notifications in your browser</p>
                </div>
                <Switch 
                  id="push-notifications" 
                  checked={pushNotifications} 
                  onCheckedChange={setPushNotifications} 
                />
              </div>
              
              <Separator />
              
              <div>
                <Label htmlFor="reminder-frequency" className="font-medium block mb-2">Medication Reminder Frequency</Label>
                <Select value={reminderFrequency} onValueChange={setReminderFrequency}>
                  <SelectTrigger id="reminder-frequency" className="w-full md:w-64">
                    <SelectValue placeholder="Select reminder frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hourly">Hourly</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="never">Never</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="privacy" className="p-6">
            <h2 className="text-xl font-heading font-semibold mb-4">Privacy Settings</h2>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="share-location" className="font-medium">Share Location</Label>
                  <p className="text-sm text-neutral-500">Allow access to your location for nearby services</p>
                </div>
                <Switch 
                  id="share-location" 
                  checked={shareLocation} 
                  onCheckedChange={setShareLocation} 
                />
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="save-search" className="font-medium">Save Search History</Label>
                  <p className="text-sm text-neutral-500">Store your recent searches for quicker access</p>
                </div>
                <Switch 
                  id="save-search" 
                  checked={saveSearchHistory} 
                  onCheckedChange={setSaveSearchHistory} 
                />
              </div>
              
              <Separator />
              
              <div>
                <Label className="font-medium block mb-2">Data Collection</Label>
                <RadioGroup value={dataCollection} onValueChange={setDataCollection} className="flex flex-col space-y-1">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="none" id="data-none" />
                    <Label htmlFor="data-none">No data collection</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="minimal" id="data-minimal" />
                    <Label htmlFor="data-minimal">Minimal (Improve app functionality)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="full" id="data-full" />
                    <Label htmlFor="data-full">Full (Help personalize your experience)</Label>
                  </div>
                </RadioGroup>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="units" className="p-6">
            <h2 className="text-xl font-heading font-semibold mb-4">Unit Settings</h2>
            <div className="space-y-6">
              <div>
                <Label className="font-medium block mb-2">Measurement System</Label>
                <RadioGroup value={unitSystem} onValueChange={setUnitSystem} className="flex flex-col space-y-1">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="metric" id="metric-system" />
                    <Label htmlFor="metric-system">Metric (kg, cm)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="imperial" id="imperial-system" />
                    <Label htmlFor="imperial-system">Imperial (lb, in)</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <Separator />
              
              <div>
                <Label className="font-medium block mb-2">Temperature Unit</Label>
                <RadioGroup value={temperature} onValueChange={setTemperature} className="flex flex-col space-y-1">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="celsius" id="celsius-temp" />
                    <Label htmlFor="celsius-temp">Celsius (°C)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="fahrenheit" id="fahrenheit-temp" />
                    <Label htmlFor="fahrenheit-temp">Fahrenheit (°F)</Label>
                  </div>
                </RadioGroup>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="accessibility" className="p-6">
            <h2 className="text-xl font-heading font-semibold mb-4">Accessibility Settings</h2>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="text-to-speech" className="font-medium">Text to Speech</Label>
                  <p className="text-sm text-neutral-500">Read text content aloud</p>
                </div>
                <Switch 
                  id="text-to-speech" 
                  checked={textToSpeech} 
                  onCheckedChange={setTextToSpeech} 
                />
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="high-contrast" className="font-medium">High Contrast Mode</Label>
                  <p className="text-sm text-neutral-500">Increase contrast for better visibility</p>
                </div>
                <Switch 
                  id="high-contrast" 
                  checked={contrastMode} 
                  onCheckedChange={setContrastMode} 
                />
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="reduce-animations" className="font-medium">Reduce Animations</Label>
                  <p className="text-sm text-neutral-500">Minimize motion effects throughout the app</p>
                </div>
                <Switch 
                  id="reduce-animations" 
                  checked={animationReduced} 
                  onCheckedChange={setAnimationReduced} 
                />
              </div>
            </div>
          </TabsContent>
        </Card>
        
        <div className="flex justify-end space-x-4">
          <Button variant="outline" onClick={handleReset}>
            Reset to Defaults
          </Button>
          <Button onClick={handleSave}>
            Save Changes
          </Button>
        </div>
      </Tabs>
    </div>
  );
};

export default Settings;