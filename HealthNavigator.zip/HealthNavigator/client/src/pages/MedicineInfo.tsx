import { useContext, useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation, useParams } from "wouter";
import SearchBar from "@/components/SearchBar";
import MedicineCard from "@/components/MedicineCard";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SidebarContext } from "../App";
import { Medicine } from "@/lib/types";

const MedicineInfo = () => {
  const { setActiveItem } = useContext(SidebarContext);
  const params = useParams();
  const medicineId = params.id || '';
  const [activeTab, setActiveTab] = useState("overview");
  
  useEffect(() => {
    setActiveItem("medicine-info");
  }, [setActiveItem]);

  // Query for medicine details 
  const { data: medicine, isLoading } = useQuery<Medicine>({
    queryKey: ['/api/medicines', medicineId],
  });

  // Query for popular medicines
  const { data: popularMedicines } = useQuery<Medicine[]>({
    queryKey: ['/api/medicines/popular'],
  });

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Search Bar */}
      <SearchBar />
      
      <h1 className="text-2xl font-heading font-semibold mb-6">
        Medicine Information
      </h1>
      
      {isLoading ? (
        <div className="p-12 bg-white rounded-xl shadow-md text-center">
          <i className="material-icons animate-spin mb-2">refresh</i>
          <p>Loading medicine information...</p>
        </div>
      ) : medicine ? (
        <>
          <MedicineCard medicine={medicine} />
          
          <div className="mt-8">
            <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid grid-cols-4 w-full mb-6">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="dosage">Dosage & Administration</TabsTrigger>
                <TabsTrigger value="warnings">Warnings</TabsTrigger>
                <TabsTrigger value="alternatives">Alternatives</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="bg-white rounded-xl shadow-md p-6">
                <h2 className="text-xl font-heading font-semibold mb-4">Overview</h2>
                <p className="mb-4">{medicine.description || "No overview information available."}</p>
                
                <h3 className="text-lg font-heading font-medium mt-6 mb-3">What is {medicine.name}?</h3>
                <p className="mb-4">{medicine.uses}</p>
                
                <h3 className="text-lg font-heading font-medium mt-6 mb-3">How it works</h3>
                <p>{medicine.mechanismOfAction || "Information about how this medication works in the body is not available."}</p>
              </TabsContent>
              
              <TabsContent value="dosage" className="bg-white rounded-xl shadow-md p-6">
                <h2 className="text-xl font-heading font-semibold mb-4">Dosage & Administration</h2>
                
                <div className="mb-6">
                  <h3 className="text-lg font-heading font-medium mb-3">Recommended Dosage</h3>
                  <p>{medicine.dosage}</p>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-heading font-medium mb-3">How to Take</h3>
                  <p>{medicine.administration || "Take as directed by your healthcare provider."}</p>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-heading font-medium mb-3">Missed Dose</h3>
                  <p>{medicine.missedDose || "If you miss a dose, take it as soon as you remember unless it's almost time for your next dose. In that case, skip the missed dose and take the next one at your regular time. Do not take two doses at once."}</p>
                </div>
                
                <div className="bg-warning bg-opacity-10 p-4 rounded-lg">
                  <div className="flex items-start">
                    <i className="material-icons text-warning mr-2">warning</i>
                    <p className="text-sm">Never adjust your dosage without consulting your healthcare provider first.</p>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="warnings" className="bg-white rounded-xl shadow-md p-6">
                <h2 className="text-xl font-heading font-semibold mb-4">Warnings & Precautions</h2>
                
                <div className="mb-6">
                  <h3 className="text-lg font-heading font-medium mb-3">Side Effects</h3>
                  <div className="mb-2">
                    {medicine.sideEffects && medicine.sideEffects.length > 0 ? (
                      medicine.sideEffects.map((effect, index) => (
                        <span 
                          key={index} 
                          className={`side-effect-tag ${
                            effect.severity === "high" 
                              ? "bg-danger bg-opacity-10 text-danger" 
                              : effect.severity === "medium"
                              ? "bg-warning bg-opacity-10 text-warning"
                              : "bg-neutral-200 text-neutral-700"
                          }`}
                        >
                          {effect.name}
                        </span>
                      ))
                    ) : (
                      <p>No side effects information available.</p>
                    )}
                  </div>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-heading font-medium mb-3">Contraindications</h3>
                  <p>{medicine.contraindications || "No contraindications information available."}</p>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-heading font-medium mb-3">Special Populations</h3>
                  <p>{medicine.specialPopulations || "Information for special populations (pregnant women, elderly, children, etc.) is not available."}</p>
                </div>
                
                <div className="bg-danger bg-opacity-10 p-4 rounded-lg mb-4">
                  <div className="flex items-start">
                    <i className="material-icons text-danger mr-2">error</i>
                    <p className="text-sm">Seek immediate medical attention if you experience severe side effects or allergic reactions.</p>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="alternatives" className="bg-white rounded-xl shadow-md p-6">
                <h2 className="text-xl font-heading font-semibold mb-4">Alternative Medications</h2>
                
                <div className="mb-6">
                  <h3 className="text-lg font-heading font-medium mb-3">Generic Alternatives</h3>
                  {medicine.genericAlternatives && medicine.genericAlternatives.length > 0 ? (
                    <ul className="list-disc pl-5">
                      {medicine.genericAlternatives.map((alt, index) => (
                        <li key={index} className="mb-1">{alt}</li>
                      ))}
                    </ul>
                  ) : (
                    <p>No generic alternatives available.</p>
                  )}
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-heading font-medium mb-3">Brand Name Alternatives</h3>
                  {medicine.brandAlternatives && medicine.brandAlternatives.length > 0 ? (
                    <ul className="list-disc pl-5">
                      {medicine.brandAlternatives.map((alt, index) => (
                        <li key={index} className="mb-1">{alt}</li>
                      ))}
                    </ul>
                  ) : (
                    <p>No brand name alternatives available.</p>
                  )}
                </div>
                
                <div className="bg-primary bg-opacity-10 p-4 rounded-lg">
                  <div className="flex items-start">
                    <i className="material-icons text-primary mr-2">info</i>
                    <p className="text-sm">Always consult with your healthcare provider before switching medications.</p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </>
      ) : (
        <div className="p-12 bg-white rounded-xl shadow-md text-center">
          <p>Medicine information not found.</p>
        </div>
      )}
      
      {/* Popular Medications */}
      {popularMedicines && popularMedicines.length > 0 && (
        <div className="mt-8">
          <h2 className="text-xl font-heading font-semibold mb-4">Popular Medications</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {popularMedicines.map((med, index) => (
              <Card key={index} className="p-4 hover:shadow-md transition-shadow">
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-primary bg-opacity-10 flex items-center justify-center mr-3">
                    <i className="material-icons text-primary">medication</i>
                  </div>
                  <div>
                    <h3 className="font-medium">{med.name}</h3>
                    <p className="text-sm text-neutral-500">{med.category}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default MedicineInfo;
