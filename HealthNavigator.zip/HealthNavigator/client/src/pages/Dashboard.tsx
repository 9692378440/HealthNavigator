import { useContext, useEffect } from "react";
import SearchBar from "@/components/SearchBar";
import FeatureCard from "@/components/FeatureCard";
import MedicineCard from "@/components/MedicineCard";
import DrugInteractionChecker from "@/components/DrugInteractionChecker";
import SymptomChecker from "@/components/SymptomChecker";
import NearbyServices from "@/components/NearbyServices";
import { useQuery } from "@tanstack/react-query";
import { SidebarContext } from "../App";
import { Medicine } from "@/lib/types";

const Dashboard = () => {
  const { setActiveItem } = useContext(SidebarContext);
  
  useEffect(() => {
    setActiveItem("dashboard");
  }, [setActiveItem]);

  // Query for featured medicine
  const { data: featuredMedicine, isLoading: loadingMedicine } = useQuery<Medicine>({
    queryKey: ['/api/medicines/featured'],
  });

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Search Bar */}
      <SearchBar />

      {/* Feature Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
        <FeatureCard
          title="AI Symptom Checker"
          description="Describe your symptoms and get AI-powered suggestions about possible conditions."
          icon="psychology"
          iconBgColor="bg-primary-light bg-opacity-20"
          iconColor="text-primary"
          buttonText="Start Symptom Check"
          buttonIcon="add"
          link="/symptom-checker"
        />

        <FeatureCard
          title="Drug Interaction Checker"
          description="Check if your medications have potentially harmful interactions."
          icon="sync_problem"
          iconBgColor="bg-accent-light bg-opacity-20"
          iconColor="text-accent"
          buttonText="Check Interactions"
          buttonIcon="medication"
          link="/drug-interactions"
        />

        <FeatureCard
          title="Nearby Medical Services"
          description="Find hospitals, clinics, and pharmacies near your location."
          icon="location_on"
          iconBgColor="bg-secondary-light bg-opacity-20"
          iconColor="text-secondary"
          buttonText="View Map"
          buttonIcon="map"
          link="/nearby-services"
        />
      </div>

      {/* Medicine Information */}
      <div className="mb-8">
        <h2 className="text-xl font-heading font-semibold mb-4">Medicine Information</h2>
        
        {loadingMedicine ? (
          <div className="p-12 bg-white rounded-xl shadow-md text-center">
            <i className="material-icons animate-spin mb-2">refresh</i>
            <p>Loading medicine information...</p>
          </div>
        ) : featuredMedicine ? (
          <MedicineCard medicine={featuredMedicine} />
        ) : (
          <div className="p-12 bg-white rounded-xl shadow-md text-center">
            <p>No medicine information available.</p>
          </div>
        )}
      </div>

      {/* Drug Interactions Section */}
      <div className="mb-8">
        <h2 className="text-xl font-heading font-semibold mb-4">Drug Interaction Results</h2>
        <DrugInteractionChecker initialMedications={["Lisinopril", "Aspirin", "Ibuprofen"]} />
      </div>

      {/* Symptom Checker Section */}
      <div className="mb-8">
        <h2 className="text-xl font-heading font-semibold mb-4">AI Symptom Checker</h2>
        <SymptomChecker initialSymptoms={["Headache", "Fatigue", "Dizziness"]} />
      </div>

      {/* Nearby Medical Services Section */}
      <div className="mb-8">
        <h2 className="text-xl font-heading font-semibold mb-4">Nearby Medical Services</h2>
        <NearbyServices />
      </div>
    </div>
  );
};

export default Dashboard;
