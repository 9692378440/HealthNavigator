import { useContext, useEffect } from "react";
import SearchBar from "@/components/SearchBar";
import NearbyServices from "@/components/NearbyServices";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SidebarContext } from "../App";

const NearbyServicesPage = () => {
  const { setActiveItem } = useContext(SidebarContext);
  
  useEffect(() => {
    setActiveItem("nearby-services");
  }, [setActiveItem]);

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Search Bar */}
      <SearchBar />
      
      <h1 className="text-2xl font-heading font-semibold mb-6">
        Nearby Medical Services
      </h1>
      
      <Tabs defaultValue="map" className="mb-6">
        <TabsList className="w-full mb-6">
          <TabsTrigger value="map" className="flex-1">
            <i className="material-icons mr-2">map</i> Map View
          </TabsTrigger>
          <TabsTrigger value="list" className="flex-1">
            <i className="material-icons mr-2">format_list_bulleted</i> List View
          </TabsTrigger>
          <TabsTrigger value="emergency" className="flex-1">
            <i className="material-icons mr-2">local_hospital</i> Emergency Services
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="map">
          <NearbyServices />
        </TabsContent>
        
        <TabsContent value="list">
          <Card className="p-6">
            <div className="mb-4">
              <h2 className="text-lg font-heading font-semibold mb-4">All Medical Services</h2>
              <p className="text-neutral-600 mb-4">
                View a comprehensive list of medical services sorted by distance from your current location.
              </p>
              <NearbyServices />
            </div>
          </Card>
        </TabsContent>
        
        <TabsContent value="emergency">
          <Card className="p-6">
            <div className="bg-danger bg-opacity-10 rounded-lg p-4 mb-6">
              <div className="flex items-center">
                <i className="material-icons text-danger mr-3">emergency</i>
                <div>
                  <h3 className="font-heading font-medium text-danger">Emergency Medical Assistance</h3>
                  <p className="text-sm">
                    If you're experiencing a medical emergency, call 911 immediately or go to your nearest emergency room.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="bg-white rounded-lg shadow-sm p-5 border">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full bg-danger bg-opacity-10 flex items-center justify-center mr-4">
                    <i className="material-icons text-danger">call</i>
                  </div>
                  <div>
                    <h3 className="font-heading font-medium">Emergency Contacts</h3>
                    <p className="text-sm text-neutral-500">Call for immediate assistance</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-2 border-b">
                    <span className="font-medium">Emergency Services</span>
                    <Button variant="outline" className="rounded-full px-3 py-1 h-auto text-sm">
                      <i className="material-icons text-danger mr-1">call</i> 911
                    </Button>
                  </div>
                  <div className="flex justify-between items-center p-2 border-b">
                    <span className="font-medium">Poison Control</span>
                    <Button variant="outline" className="rounded-full px-3 py-1 h-auto text-sm">
                      <i className="material-icons text-danger mr-1">call</i> 1-800-222-1222
                    </Button>
                  </div>
                  <div className="flex justify-between items-center p-2">
                    <span className="font-medium">Suicide Prevention</span>
                    <Button variant="outline" className="rounded-full px-3 py-1 h-auto text-sm">
                      <i className="material-icons text-danger mr-1">call</i> 988
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm p-5 border">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full bg-primary bg-opacity-10 flex items-center justify-center mr-4">
                    <i className="material-icons text-primary">local_hospital</i>
                  </div>
                  <div>
                    <h3 className="font-heading font-medium">Nearest Emergency Rooms</h3>
                    <p className="text-sm text-neutral-500">For critical medical situations</p>
                  </div>
                </div>
                <NearbyServices initialType="hospital" initialRadius={10} />
              </div>
            </div>
            
            <div className="bg-neutral-50 rounded-lg p-4">
              <h3 className="font-heading font-medium mb-2">When to go to the Emergency Room:</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                <div className="flex items-start">
                  <i className="material-icons text-danger text-sm mr-2 mt-0.5">arrow_right</i>
                  <span>Severe chest pain or difficulty breathing</span>
                </div>
                <div className="flex items-start">
                  <i className="material-icons text-danger text-sm mr-2 mt-0.5">arrow_right</i>
                  <span>Severe bleeding that can't be stopped</span>
                </div>
                <div className="flex items-start">
                  <i className="material-icons text-danger text-sm mr-2 mt-0.5">arrow_right</i>
                  <span>Sudden severe headache or loss of vision</span>
                </div>
                <div className="flex items-start">
                  <i className="material-icons text-danger text-sm mr-2 mt-0.5">arrow_right</i>
                  <span>Severe burns or injuries</span>
                </div>
                <div className="flex items-start">
                  <i className="material-icons text-danger text-sm mr-2 mt-0.5">arrow_right</i>
                  <span>Sudden confusion or change in mental status</span>
                </div>
                <div className="flex items-start">
                  <i className="material-icons text-danger text-sm mr-2 mt-0.5">arrow_right</i>
                  <span>Broken bones or dislocated joints</span>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Health Insurance Info */}
      <div className="mb-8">
        <h2 className="text-xl font-heading font-semibold mb-4">Healthcare Resources</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="p-4 hover:shadow-md transition-shadow">
            <div className="flex items-center mb-3">
              <div className="w-10 h-10 rounded-full bg-primary bg-opacity-10 flex items-center justify-center mr-3">
                <i className="material-icons text-primary">payments</i>
              </div>
              <h3 className="font-medium">Insurance Information</h3>
            </div>
            <p className="text-sm text-neutral-600 mb-3">
              Check which facilities accept your insurance before visiting.
            </p>
            <Button variant="outline" className="w-full">
              Insurance Tools
            </Button>
          </Card>
          
          <Card className="p-4 hover:shadow-md transition-shadow">
            <div className="flex items-center mb-3">
              <div className="w-10 h-10 rounded-full bg-secondary bg-opacity-10 flex items-center justify-center mr-3">
                <i className="material-icons text-secondary">event_available</i>
              </div>
              <h3 className="font-medium">Find Appointments</h3>
            </div>
            <p className="text-sm text-neutral-600 mb-3">
              Search for available appointments at nearby clinics.
            </p>
            <Button variant="outline" className="w-full">
              Book Appointment
            </Button>
          </Card>
          
          <Card className="p-4 hover:shadow-md transition-shadow">
            <div className="flex items-center mb-3">
              <div className="w-10 h-10 rounded-full bg-accent bg-opacity-10 flex items-center justify-center mr-3">
                <i className="material-icons text-accent">support_agent</i>
              </div>
              <h3 className="font-medium">Telehealth Options</h3>
            </div>
            <p className="text-sm text-neutral-600 mb-3">
              Connect with healthcare providers from home.
            </p>
            <Button variant="outline" className="w-full">
              Virtual Care
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default NearbyServicesPage;
