import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import MedicineInfo from "@/pages/MedicineInfo";
import SymptomCheckerPage from "@/pages/SymptomCheckerPage";
import DrugInteractionsPage from "@/pages/DrugInteractionsPage";
import NearbyServicesPage from "@/pages/NearbyServicesPage";
import UserProfile from "@/pages/UserProfile";
import Settings from "@/pages/Settings";
import ConditionInfoPage from "@/pages/ConditionInfoPage";
import { useState, createContext } from "react";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import MobileNav from "@/components/MobileNav";
import { useMobile } from "@/hooks/use-mobile";

export const SidebarContext = createContext<{
  activeItem: string;
  setActiveItem: (item: string) => void;
}>({
  activeItem: "dashboard",
  setActiveItem: () => {},
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/medicine-info/:id" component={MedicineInfo} />
      <Route path="/medicine-info" component={MedicineInfo} />
      <Route path="/symptom-checker" component={SymptomCheckerPage} />
      <Route path="/drug-interactions" component={DrugInteractionsPage} />
      <Route path="/nearby-services" component={NearbyServicesPage} />
      <Route path="/profile" component={UserProfile} />
      <Route path="/settings" component={Settings} />
      <Route path="/condition/:id" component={ConditionInfoPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [activeItem, setActiveItem] = useState("dashboard");
  const isMobile = useMobile();

  return (
    <QueryClientProvider client={queryClient}>
      <SidebarContext.Provider value={{ activeItem, setActiveItem }}>
        <div className="flex flex-col min-h-screen bg-neutral-50">
          <Header />
          
          <div className="flex flex-1 overflow-hidden">
            {!isMobile && <Sidebar />}
            
            <main className="flex-1 overflow-y-auto">
              <Router />
            </main>
          </div>
          
          {isMobile && <MobileNav />}
        </div>
      </SidebarContext.Provider>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
