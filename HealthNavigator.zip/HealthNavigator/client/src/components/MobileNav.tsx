import { useContext } from "react";
import { Link } from "wouter";
import { SidebarContext } from "../App";

interface NavItem {
  id: string;
  icon: string;
  label: string;
  path: string;
}

const mobileNavItems: NavItem[] = [
  { id: "dashboard", icon: "home", label: "Home", path: "/" },
  { id: "smart-search", icon: "search", label: "Search", path: "/" },
  { id: "medicine-info", icon: "medication", label: "Meds", path: "/medicine-info" },
  { id: "symptom-checker", icon: "psychology", label: "Symptoms", path: "/symptom-checker" },
  { id: "settings", icon: "settings", label: "Settings", path: "/settings" },
];

const MobileNav = () => {
  const { activeItem, setActiveItem } = useContext(SidebarContext);

  const handleItemClick = (id: string) => {
    setActiveItem(id);
  };

  return (
    <div className="md:hidden bg-white shadow-md p-2">
      <div className="flex justify-around">
        {mobileNavItems.map((item) => (
          <Link key={item.id} href={item.path}>
            <button
              className="p-2 flex flex-col items-center"
              onClick={() => handleItemClick(item.id)}
            >
              <i className={`material-icons ${
                activeItem === item.id ? "text-primary" : "text-neutral-500"
              }`}>
                {item.icon}
              </i>
              <span className="text-xs">{item.label}</span>
            </button>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default MobileNav;
