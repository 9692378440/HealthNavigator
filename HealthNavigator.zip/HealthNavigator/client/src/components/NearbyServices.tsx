import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { useQuery } from "@tanstack/react-query";
import { MedicalService } from "@/lib/types";

interface NearbyServicesProps {
  initialRadius?: number;
  initialType?: string;
}

const NearbyServices = ({ initialRadius = 5, initialType = "all" }: NearbyServicesProps) => {
  const [serviceType, setServiceType] = useState(initialType);
  const [radius, setRadius] = useState(initialRadius);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);

  // Get user's location
  useEffect(() => {
    setIsLoadingLocation(true);
    
    // Use a default location after a timeout in case geolocation takes too long or fails
    const timeoutId = setTimeout(() => {
      if (!location) {
        console.log("Using default location due to timeout");
        setLocation({ lat: 37.7749, lng: -122.4194 }); // San Francisco default
        setIsLoadingLocation(false);
      }
    }, 5000); // 5 second timeout
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          clearTimeout(timeoutId);
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
          setIsLoadingLocation(false);
        },
        (error) => {
          clearTimeout(timeoutId);
          console.error("Error getting location:", error);
          setIsLoadingLocation(false);
          // Default to a fallback location if permission denied or other error
          setLocation({ lat: 37.7749, lng: -122.4194 }); // San Francisco
        },
        { 
          enableHighAccuracy: false, // High accuracy may cause issues in some browsers
          timeout: 10000, // 10 second timeout
          maximumAge: 300000 // Accept cached positions up to 5 minutes old
        }
      );
    } else {
      clearTimeout(timeoutId);
      console.error("Geolocation is not supported by this browser.");
      setIsLoadingLocation(false);
      // Default to a fallback location
      setLocation({ lat: 37.7749, lng: -122.4194 }); // San Francisco
    }
    
    return () => clearTimeout(timeoutId);
  }, []);

  // Query for medical services
  const { data: services, isLoading: loadingServices } = useQuery<MedicalService[]>({
    queryKey: ['/api/services/nearby', location, radius, serviceType],
    enabled: !!location,
    queryFn: async () => {
      if (!location) return [];
      const params = new URLSearchParams({
        lat: location.lat.toString(),
        lng: location.lng.toString(),
        radius: radius.toString(),
        ...(serviceType && serviceType !== "all" ? { type: serviceType } : {})
      });
      const res = await fetch(`/api/services/nearby?${params}`);
      return res.json();
    }
  });

  const handleServiceTypeChange = (type: string) => {
    setServiceType(type);
  };

  const handleRadiusChange = (value: number[]) => {
    setRadius(value[0]);
  };

  const getServiceIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "hospital":
        return "local_hospital";
      case "pharmacy":
        return "medication";
      case "clinic":
      case "urgent care":
        return "medical_services";
      default:
        return "health_and_safety";
    }
  };

  const getServiceIconBackground = (type: string) => {
    switch (type.toLowerCase()) {
      case "hospital":
        return "bg-primary bg-opacity-10";
      case "pharmacy":
        return "bg-secondary bg-opacity-10";
      case "urgent care":
        return "bg-accent bg-opacity-10";
      case "clinic":
        return "bg-warning bg-opacity-10";
      default:
        return "bg-neutral-200";
    }
  };

  const getServiceIconColor = (type: string) => {
    switch (type.toLowerCase()) {
      case "hospital":
        return "text-primary";
      case "pharmacy":
        return "text-secondary";
      case "urgent care":
        return "text-accent";
      case "clinic":
        return "text-warning";
      default:
        return "text-neutral-500";
    }
  };

  return (
    <Card className="bg-white rounded-xl shadow-md overflow-hidden">
      <div className="h-64 bg-neutral-200 relative">
        {/* This would be replaced with an actual map component */}
        <div className="w-full h-full flex items-center justify-center bg-neutral-100">
          {isLoadingLocation ? (
            <div className="text-center">
              <i className="material-icons animate-spin mb-2">location_searching</i>
              <p>Locating you...</p>
            </div>
          ) : (
            <>
              <div className="bg-black bg-opacity-50 text-white p-2 rounded">
                Map View - {location ? `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}` : 'Location not available'}
              </div>
              {/* Map content would go here */}
            </>
          )}
        </div>
        <div className="absolute bottom-4 left-4 bg-white shadow rounded-lg p-2 flex items-center">
          <i className="material-icons text-primary mr-1">my_location</i>
          <span className="text-sm">Current Location</span>
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex flex-col md:flex-row items-start mb-6">
          <div className="w-full md:w-1/2 mb-4 md:mb-0">
            <h3 className="font-heading font-medium mb-2">Filter By</h3>
            <div className="flex flex-wrap gap-2">
              <Button 
                variant={serviceType === "all" ? "default" : "outline"}
                className={`rounded-full px-3 py-1 text-sm ${
                  serviceType === "all" ? "bg-primary text-white" : "bg-neutral-100 hover:bg-neutral-200"
                }`}
                onClick={() => handleServiceTypeChange("all")}
              >
                All
              </Button>
              <Button 
                variant={serviceType === "hospital" ? "default" : "outline"}
                className={`rounded-full px-3 py-1 text-sm ${
                  serviceType === "hospital" ? "bg-primary text-white" : "bg-neutral-100 hover:bg-neutral-200"
                }`}
                onClick={() => handleServiceTypeChange("hospital")}
              >
                Hospitals
              </Button>
              <Button 
                variant={serviceType === "clinic" ? "default" : "outline"}
                className={`rounded-full px-3 py-1 text-sm ${
                  serviceType === "clinic" ? "bg-primary text-white" : "bg-neutral-100 hover:bg-neutral-200"
                }`}
                onClick={() => handleServiceTypeChange("clinic")}
              >
                Clinics
              </Button>
              <Button 
                variant={serviceType === "pharmacy" ? "default" : "outline"}
                className={`rounded-full px-3 py-1 text-sm ${
                  serviceType === "pharmacy" ? "bg-primary text-white" : "bg-neutral-100 hover:bg-neutral-200"
                }`}
                onClick={() => handleServiceTypeChange("pharmacy")}
              >
                Pharmacies
              </Button>
              <Button 
                variant={serviceType === "urgent care" ? "default" : "outline"}
                className={`rounded-full px-3 py-1 text-sm ${
                  serviceType === "urgent care" ? "bg-primary text-white" : "bg-neutral-100 hover:bg-neutral-200"
                }`}
                onClick={() => handleServiceTypeChange("urgent care")}
              >
                Urgent Care
              </Button>
            </div>
          </div>
          <div className="w-full md:w-1/2">
            <h3 className="font-heading font-medium mb-2">Distance</h3>
            <div className="flex items-center">
              <div className="w-full mr-2">
                <Slider 
                  defaultValue={[radius]} 
                  max={20} 
                  min={1} 
                  step={1} 
                  onValueChange={handleRadiusChange}
                />
              </div>
              <span className="text-sm font-medium">{radius} miles</span>
            </div>
          </div>
        </div>
        
        {loadingServices ? (
          <div className="py-8 text-center">
            <i className="material-icons animate-spin mb-2">refresh</i>
            <p>Finding medical services near you...</p>
          </div>
        ) : services && services.length > 0 ? (
          <div className="divide-y">
            {services.map((service, index) => (
              <div key={index} className="py-4">
                <div className="flex items-start">
                  <div className={`w-12 h-12 rounded-full ${getServiceIconBackground(service.type)} flex items-center justify-center mr-4`}>
                    <i className={`material-icons ${getServiceIconColor(service.type)}`}>{getServiceIcon(service.type)}</i>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-medium">{service.name}</h4>
                        <p className="text-sm text-neutral-500">
                          {service.type} • {typeof service.distance === 'number' ? service.distance.toFixed(1) : parseFloat(service.distance).toFixed(1)} miles away
                        </p>
                      </div>
                      <div className="flex items-center">
                        <span className={`text-sm bg-success bg-opacity-10 text-success rounded-full px-2 py-0.5 mr-2`}>
                          {service.openNow ? "Open" : "Closed"} {service.hoursToday}
                        </span>
                        <span className="text-sm font-medium text-primary">{typeof service.rating === 'number' ? service.rating.toFixed(1) : parseFloat(service.rating).toFixed(1)} ★</span>
                      </div>
                    </div>
                    <p className="text-sm text-neutral-600 mt-1">{service.address}</p>
                    <div className="mt-2 flex flex-wrap">
                      <Button 
                        variant="link" 
                        className="text-primary hover:underline text-sm mr-4"
                        onClick={() => window.open(`tel:${service.phone}`)}
                      >
                        <i className="material-icons text-sm mr-1">call</i>
                        Call
                      </Button>
                      <Button 
                        variant="link" 
                        className="text-primary hover:underline text-sm mr-4"
                        onClick={() => window.open(`https://maps.google.com/?q=${service.address}`)}
                      >
                        <i className="material-icons text-sm mr-1">directions</i>
                        Directions
                      </Button>
                      <Button 
                        variant="link" 
                        className="text-primary hover:underline text-sm"
                        onClick={() => console.log(`More info for ${service.name}`)}
                      >
                        <i className="material-icons text-sm mr-1">info</i>
                        More Info
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-8 text-center border rounded-lg">
            <i className="material-icons text-neutral-400 text-4xl mb-2">location_off</i>
            <p className="text-neutral-600">No medical services found within {radius} miles</p>
            <p className="text-sm text-neutral-500 mt-1">Try increasing your search radius</p>
          </div>
        )}
        
        {services && services.length > 0 && (
          <div className="mt-4 text-center">
            <Button 
              variant="link" 
              className="px-4 py-2 text-primary hover:underline"
              onClick={() => console.log("Show more results clicked")}
            >
              Show More Results
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
};

export default NearbyServices;
