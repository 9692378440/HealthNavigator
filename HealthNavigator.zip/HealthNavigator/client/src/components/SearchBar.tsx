import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { SearchResult } from "@/lib/types";

const SearchBar = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [showResults, setShowResults] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Search query
  const { data: searchResults, isLoading } = useQuery<SearchResult[]>({
    queryKey: ['/api/search', searchTerm],
    queryFn: async () => {
      const response = await fetch(`/api/search?q=${encodeURIComponent(searchTerm)}`);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    },
    enabled: searchTerm.length >= 2, // Only search when at least 2 characters are entered
  });

  // Handle click outside to close search results
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleSearchInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    if (e.target.value.length >= 2) {
      setShowResults(true);
    } else {
      setShowResults(false);
    }
  };

  const handleVoiceSearch = () => {
    // Implement voice search in a future enhancement
    console.log("Voice search clicked");
  };

  const handleImageSearch = () => {
    // Implement image search in a future enhancement
    console.log("Image search clicked");
  };

  const handleSearch = () => {
    // Implement full search
    console.log("Search button clicked");
  };

  const [_, navigate] = useLocation();
  
  const handleResultClick = (result: SearchResult) => {
    console.log("Selected:", result);
    setShowResults(false);
    
    // Navigate based on result type
    if (result.type === "Medication") {
      navigate(`/medicine-info/${result.id}`);
    } else if (result.type === "Symptom") {
      navigate(`/symptom-checker?symptom=${encodeURIComponent(result.title)}`);
    } else if (result.type === "Disease") {
      navigate(`/condition/${result.id}`);
    }
  };

  return (
    <div className="search-container mb-8" ref={searchContainerRef}>
      <div className="flex items-center bg-white rounded-full shadow-md p-1 pl-4">
        <i className="material-icons text-neutral-400">search</i>
        <Input
          type="text"
          placeholder="Search for diseases, symptoms, or medications..."
          className="flex-1 px-4 py-2 border-none shadow-none focus-visible:ring-0"
          value={searchTerm}
          onChange={handleSearchInput}
          onFocus={() => searchTerm.length >= 2 && setShowResults(true)}
        />
        <Button 
          variant="ghost" 
          className="p-2 rounded-full text-primary hover:bg-neutral-100"
          onClick={handleVoiceSearch}
        >
          <i className="material-icons">mic</i>
        </Button>
        <Button 
          variant="ghost" 
          className="p-2 rounded-full text-primary hover:bg-neutral-100"
          onClick={handleImageSearch}
        >
          <i className="material-icons">photo_camera</i>
        </Button>
        <Button 
          className="bg-primary hover:bg-primary-dark text-white rounded-full px-5 py-2"
          onClick={handleSearch}
        >
          Search
        </Button>
      </div>
      
      {/* Search autocomplete results */}
      {showResults && searchTerm.length >= 2 && (
        <Card className="search-results bg-white rounded-lg shadow-lg mt-1">
          <div className="p-2 font-semibold text-sm text-neutral-500">
            {isLoading ? "Searching..." : "Suggestions"}
          </div>
          
          {isLoading ? (
            <div className="p-4 text-center">
              <i className="material-icons animate-spin">refresh</i> Loading results...
            </div>
          ) : searchResults && searchResults.length > 0 ? (
            searchResults.map((result, index) => (
              <div 
                key={index} 
                className="hover:bg-neutral-100 p-3 cursor-pointer"
                onClick={() => handleResultClick(result)}
              >
                <div className="font-medium">{result.title}</div>
                <div className="text-sm text-neutral-500">
                  {result.type} - {result.description}
                </div>
              </div>
            ))
          ) : searchTerm.length >= 2 ? (
            <div className="p-4 text-center text-neutral-500">
              No results found for "{searchTerm}"
            </div>
          ) : null}
          
          {/* Sample suggestions for UI demonstration */}
          {searchTerm.length >= 2 && !searchResults?.length && (
            <>
              <div 
                className="hover:bg-neutral-100 p-3 cursor-pointer"
                onClick={() => handleResultClick({
                  id: "1",
                  title: "Hypertension",
                  type: "Disease",
                  description: "High blood pressure"
                })}
              >
                <div className="font-medium">Hypertension</div>
                <div className="text-sm text-neutral-500">Disease - High blood pressure</div>
              </div>
              <div 
                className="hover:bg-neutral-100 p-3 cursor-pointer"
                onClick={() => handleResultClick({
                  id: "2",
                  title: "Headache",
                  type: "Symptom",
                  description: "Pain in the head region"
                })}
              >
                <div className="font-medium">Headache</div>
                <div className="text-sm text-neutral-500">Symptom - Pain in the head region</div>
              </div>
              <div 
                className="hover:bg-neutral-100 p-3 cursor-pointer"
                onClick={() => handleResultClick({
                  id: "3",
                  title: "Hydrochlorothiazide",
                  type: "Medication",
                  description: "Used to treat high blood pressure"
                })}
              >
                <div className="font-medium">Hydrochlorothiazide</div>
                <div className="text-sm text-neutral-500">Medication - Used to treat high blood pressure</div>
              </div>
            </>
          )}
        </Card>
      )}
    </div>
  );
};

export default SearchBar;
