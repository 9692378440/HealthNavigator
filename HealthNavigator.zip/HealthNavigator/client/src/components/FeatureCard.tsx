import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface FeatureCardProps {
  title: string;
  description: string;
  icon: string;
  iconBgColor: string;
  iconColor: string;
  buttonText: string;
  buttonIcon: string;
  link: string;
}

const FeatureCard = ({
  title,
  description,
  icon,
  iconBgColor,
  iconColor,
  buttonText,
  buttonIcon,
  link,
}: FeatureCardProps) => {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="p-6">
        <div className="flex items-center mb-4">
          <div className={`w-12 h-12 rounded-full ${iconBgColor} flex items-center justify-center`}>
            <i className={`material-icons ${iconColor}`}>{icon}</i>
          </div>
          <h2 className="ml-4 text-lg font-heading font-semibold">{title}</h2>
        </div>
        <p className="text-neutral-600 mb-4">{description}</p>
        <Link href={link}>
          <Button className="w-full bg-primary hover:bg-primary-dark text-white rounded-lg px-4 py-2 flex items-center justify-center">
            <i className="material-icons mr-2">{buttonIcon}</i>
            {buttonText}
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default FeatureCard;
