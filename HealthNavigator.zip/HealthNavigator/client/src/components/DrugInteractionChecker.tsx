import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Medication, DrugInteraction } from "@/lib/types";

interface DrugInteractionCheckerProps {
  initialMedications?: string[];
}

const DrugInteractionChecker = ({ initialMedications = [] }: DrugInteractionCheckerProps) => {
  const [medications, setMedications] = useState<string[]>(initialMedications);
  const [searchTerm, setSearchTerm] = useState("");
  const [showResults, setShowResults] = useState(false);
  const queryClient = useQueryClient();

  // Query for checking drug interactions
  const { data: interactions, isLoading: checkingInteractions, refetch } = useQuery<DrugInteraction[]>({
    queryKey: ['/api/interactions', medications],
    enabled: medications.length >= 2,
  });

  // Query for medication search
  const { data: searchResults, isLoading: searchingMedications } = useQuery<Medication[]>({
    queryKey: ['/api/medications/search', searchTerm],
    enabled: searchTerm.length >= 2 && showResults,
  });

  // Remove medication mutation
  const removeMedication = useMutation({
    mutationFn: (medicationName: string) => {
      const updatedMedications = medications.filter(med => med !== medicationName);
      setMedications(updatedMedications);
      return Promise.resolve();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/interactions'] });
    }
  });

  // Add medication mutation
  const addMedication = useMutation({
    mutationFn: (medicationName: string) => {
      if (!medications.includes(medicationName)) {
        setMedications([...medications, medicationName]);
      }
      setSearchTerm("");
      setShowResults(false);
      return Promise.resolve();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/interactions'] });
    }
  });

  useEffect(() => {
    if (medications.length >= 2) {
      refetch();
    }
  }, [medications, refetch]);

  const handleCheckInteractions = () => {
    if (medications.length >= 2) {
      refetch();
    }
  };

  const getSeverityClass = (severity: string) => {
    switch (severity) {
      case "high":
        return "drug-interaction-severity-high";
      case "medium":
        return "drug-interaction-severity-medium";
      case "low":
        return "drug-interaction-severity-low";
      default:
        return "";
    }
  };

  const getIconForSeverity = (severity: string) => {
    switch (severity) {
      case "high":
        return "warning";
      case "medium":
        return "error_outline";
      case "low":
        return "info_outline";
      default:
        return "info_outline";
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "text-danger";
      case "medium":
        return "text-warning";
      case "low":
        return "text-success";
      default:
        return "text-neutral-500";
    }
  };

  const handleDownloadReport = () => {
    console.log("Download report clicked");
    // Implement report download functionality
  };

  const handleShareWithDoctor = () => {
    console.log("Share with doctor clicked");
    // Implement share functionality
  };

  return (
    <Card className="bg-white rounded-xl shadow-md overflow-hidden p-6">
      <div className="mb-6 flex flex-wrap items-center">
        <div className="w-full md:w-1/2 mb-4 md:mb-0">
          <h3 className="font-heading font-medium mb-2">Your Medications</h3>
          <div className="flex flex-wrap gap-2">
            {medications.map((medication, index) => (
              <Badge
                key={index}
                variant="outline"
                className="bg-neutral-100 rounded-full px-3 py-1 text-sm flex items-center"
              >
                {medication}
                <button
                  className="ml-1 text-neutral-400 hover:text-neutral-600"
                  onClick={() => removeMedication.mutate(medication)}
                >
                  <i className="material-icons text-sm">close</i>
                </button>
              </Badge>
            ))}
            <div className="relative">
              <Badge
                variant="outline"
                className="bg-primary bg-opacity-10 rounded-full px-3 py-1 text-sm flex items-center text-primary cursor-pointer"
                onClick={() => setShowResults(!showResults)}
              >
                <i className="material-icons text-sm mr-1">add</i>
                Add medication
              </Badge>
              
              {showResults && (
                <Card className="absolute top-full left-0 mt-1 w-64 z-10 p-2">
                  <input
                    type="text"
                    className="w-full p-2 border rounded mb-2"
                    placeholder="Type medication name..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    autoFocus
                  />
                  
                  {searchingMedications ? (
                    <div className="p-2 text-center">
                      <i className="material-icons animate-spin">refresh</i> Searching...
                    </div>
                  ) : searchResults && searchResults.length > 0 ? (
                    <div className="max-h-48 overflow-y-auto">
                      {searchResults.map((med, idx) => (
                        <div
                          key={idx}
                          className="p-2 hover:bg-neutral-100 cursor-pointer"
                          onClick={() => addMedication.mutate(med.name)}
                        >
                          {med.name}
                        </div>
                      ))}
                    </div>
                  ) : searchTerm.length >= 2 ? (
                    <div className="p-2 text-center text-neutral-500">
                      No medications found
                    </div>
                  ) : (
                    <div className="p-2 text-center text-neutral-500">
                      Type to search for medications
                    </div>
                  )}
                  
                  {/* Sample medication suggestions for UI demonstration */}
                  {!searchResults?.length && searchTerm.length < 2 && (
                    <div className="max-h-48 overflow-y-auto">
                      {["Lisinopril", "Aspirin", "Ibuprofen", "Metformin", "Simvastatin"].map((med, idx) => (
                        <div
                          key={idx}
                          className="p-2 hover:bg-neutral-100 cursor-pointer"
                          onClick={() => addMedication.mutate(med)}
                        >
                          {med}
                        </div>
                      ))}
                    </div>
                  )}
                </Card>
              )}
            </div>
          </div>
        </div>
        <div className="w-full md:w-1/2 flex justify-end">
          <Button
            className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark"
            onClick={handleCheckInteractions}
            disabled={medications.length < 2 || checkingInteractions}
          >
            {checkingInteractions ? (
              <>
                <i className="material-icons mr-1 text-sm animate-spin">refresh</i>
                Checking...
              </>
            ) : (
              <>
                <i className="material-icons mr-1 text-sm">refresh</i>
                Check Interactions
              </>
            )}
          </Button>
        </div>
      </div>
      
      {/* Results */}
      {medications.length < 2 ? (
        <div className="bg-neutral-50 rounded-lg p-4 mb-4 text-center">
          <p>Add at least two medications to check for interactions.</p>
        </div>
      ) : checkingInteractions ? (
        <div className="p-4 text-center">
          <i className="material-icons animate-spin mr-2">refresh</i>
          Analyzing drug interactions...
        </div>
      ) : interactions && interactions.length > 0 ? (
        <div className="mb-4">
          {interactions.map((interaction, index) => (
            <div 
              key={index} 
              className={`bg-opacity-10 rounded-lg p-4 mb-4 ${getSeverityClass(interaction.severity)}`}
            >
              <div className="flex items-start">
                <i className={`material-icons ${getSeverityColor(interaction.severity)} mr-2`}>
                  {getIconForSeverity(interaction.severity)}
                </i>
                <div>
                  <h4 className={`font-heading font-medium ${getSeverityColor(interaction.severity)}`}>
                    {interaction.severity === "high" && "Major"}
                    {interaction.severity === "medium" && "Moderate"}
                    {interaction.severity === "low" && "Minor"}
                    {" Interaction: "}
                    {interaction.medications.join(" + ")}
                  </h4>
                  <p className="text-neutral-600">{interaction.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : medications.length >= 2 ? (
        <div className="bg-success bg-opacity-10 rounded-lg p-4 mb-4 drug-interaction-severity-low">
          <div className="flex items-start">
            <i className="material-icons text-success mr-2">check_circle</i>
            <div>
              <h4 className="font-heading font-medium text-success">No Interactions Found</h4>
              <p className="text-neutral-600">
                No known interactions were found between these medications. However, always consult
                with your healthcare provider before starting or stopping any medications.
              </p>
            </div>
          </div>
        </div>
      ) : null}
      
      {medications.length >= 2 && !checkingInteractions && (
        <div className="text-center">
          <Button 
            variant="link" 
            className="px-4 py-2 text-primary hover:underline"
            onClick={handleDownloadReport}
          >
            <i className="material-icons mr-1 text-sm">picture_as_pdf</i>
            Download Report
          </Button>
          <Button 
            variant="link" 
            className="px-4 py-2 text-primary hover:underline"
            onClick={handleShareWithDoctor}
          >
            <i className="material-icons mr-1 text-sm">share</i>
            Share with Doctor
          </Button>
        </div>
      )}
    </Card>
  );
};

export default DrugInteractionChecker;
