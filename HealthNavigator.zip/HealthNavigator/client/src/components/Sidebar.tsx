import { useContext } from "react";
import { Link } from "wouter";
import { SidebarContext } from "../App";

interface NavItem {
  id: string;
  icon: string;
  label: string;
  path: string;
}

const navItems: NavItem[] = [
  { id: "dashboard", icon: "home", label: "Dashboard", path: "/" },
  { id: "smart-search", icon: "search", label: "Smart Search", path: "/" },
  { id: "medicine-info", icon: "medication", label: "Medicine Info", path: "/medicine-info" },
  { id: "symptom-checker", icon: "psychology", label: "Symptom Checker", path: "/symptom-checker" },
  { id: "drug-interactions", icon: "sync_problem", label: "Drug Interactions", path: "/drug-interactions" },
  { id: "nearby-services", icon: "location_on", label: "Nearby Services", path: "/nearby-services" },
  { id: "health-blog", icon: "article", label: "Health Blog", path: "/" },
  { id: "settings", icon: "settings", label: "Settings", path: "/settings" },
];

const Sidebar = () => {
  const { activeItem, setActiveItem } = useContext(SidebarContext);

  const handleItemClick = (id: string) => {
    setActiveItem(id);
  };

  return (
    <nav className="hidden md:block w-64 bg-white shadow-md">
      <div className="p-4">
        {navItems.map((item) => (
          <Link key={item.id} href={item.path}>
            <div
              className={`side-nav-item px-4 py-3 rounded-lg flex items-center cursor-pointer ${
                activeItem === item.id ? "active" : ""
              }`}
              onClick={() => handleItemClick(item.id)}
            >
              <i className={`material-icons mr-3 ${
                activeItem === item.id ? "text-primary" : "text-neutral-500"
              }`}>
                {item.icon}
              </i>
              <span>{item.label}</span>
            </div>
          </Link>
        ))}
      </div>
    </nav>
  );
};

export default Sidebar;
