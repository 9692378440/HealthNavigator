import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { Medicine, SideEffect } from "@/lib/types";

interface MedicineCardProps {
  medicine: Medicine;
}

const MedicineCard = ({ medicine }: MedicineCardProps) => {
  const [loading, setLoading] = useState(false);

  const getSeverityClass = (severity: string) => {
    switch (severity) {
      case "high":
        return "bg-danger bg-opacity-10 text-danger";
      case "medium":
        return "bg-warning bg-opacity-10 text-warning";
      case "low":
        return "bg-neutral-200 text-neutral-700";
      default:
        return "bg-neutral-200 text-neutral-700";
    }
  };

  const handleSaveToProfile = async () => {
    setLoading(true);
    try {
      // Call API to save medicine to user profile
      await fetch("/api/user/save-medicine", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ medicineId: medicine.id }),
        credentials: "include"
      });
      setTimeout(() => setLoading(false), 500); // Simulate API call
    } catch (error) {
      console.error("Error saving medicine:", error);
      setLoading(false);
    }
  };

  return (
    <Card className="bg-white rounded-xl shadow-md overflow-hidden">
      <div className="flex flex-col md:flex-row">
        <div className="w-full md:w-1/3 bg-primary bg-opacity-10 p-6 flex flex-col items-center justify-center">
          {medicine.imageUrl && (
            <img 
              src={medicine.imageUrl} 
              alt={`${medicine.name} medication`} 
              className="w-24 h-24 rounded-lg shadow pill-image mb-4" 
            />
          )}
          <h3 className="text-lg font-heading font-semibold text-center">{medicine.name}</h3>
          <p className="text-neutral-600 text-sm text-center mb-2">{medicine.category}</p>
          <div className="flex items-center justify-center">
            <span className="bg-primary bg-opacity-20 text-primary text-xs rounded-full px-3 py-1">
              {medicine.prescriptionRequired ? "Prescription Required" : "Over the Counter"}
            </span>
          </div>
        </div>
        
        <div className="w-full md:w-2/3 p-6">
          <div className="flex flex-wrap mb-4">
            <div className="w-full sm:w-1/2 md:w-1/3 p-2">
              <div className="text-sm text-neutral-500">Common Dosage</div>
              <div className="font-medium">{medicine.dosage}</div>
            </div>
            <div className="w-full sm:w-1/2 md:w-1/3 p-2">
              <div className="text-sm text-neutral-500">Form</div>
              <div className="font-medium">{medicine.form}</div>
            </div>
            <div className="w-full sm:w-1/2 md:w-1/3 p-2">
              <div className="text-sm text-neutral-500">Generic Available</div>
              <div className="font-medium">{medicine.genericAvailable ? "Yes" : "No"}</div>
            </div>
          </div>
          
          <div className="mb-4">
            <h4 className="font-heading font-medium mb-2">Common Uses</h4>
            <p className="text-neutral-600">{medicine.uses}</p>
          </div>
          
          <div className="mb-4">
            <h4 className="font-heading font-medium mb-2">Side Effects</h4>
            <div>
              {medicine.sideEffects.map((effect: SideEffect, index) => (
                <span 
                  key={index} 
                  className={`side-effect-tag ${getSeverityClass(effect.severity)}`}
                >
                  {effect.name}
                </span>
              ))}
            </div>
          </div>
          
          <div className="flex flex-wrap items-center justify-between">
            <Button 
              variant="outline" 
              className="px-4 py-2 border border-primary text-primary rounded-lg hover:bg-primary hover:bg-opacity-10 mb-2 sm:mb-0"
              onClick={handleSaveToProfile}
              disabled={loading}
            >
              {loading ? (
                <>
                  <i className="material-icons mr-1 text-sm animate-spin">refresh</i>
                  Saving...
                </>
              ) : (
                <>
                  <i className="material-icons mr-1 text-sm">bookmark</i>
                  Save to Profile
                </>
              )}
            </Button>
            <div className="flex flex-wrap space-x-2">
              <Link href={`/drug-interactions?medication=${medicine.id}`}>
                <Button 
                  variant="outline" 
                  className="px-4 py-2 border border-primary text-primary rounded-lg hover:bg-primary hover:bg-opacity-10 mb-2 sm:mb-0"
                >
                  <i className="material-icons mr-1 text-sm">sync_problem</i>
                  Check Interactions
                </Button>
              </Link>
              <Link href={`/medicine-info/${medicine.id}`}>
                <Button 
                  className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark"
                >
                  <i className="material-icons mr-1 text-sm">assignment</i>
                  Full Details
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default MedicineCard;
