import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Symptom, ConditionMatch } from "@/lib/types";

interface SymptomCheckerProps {
  initialSymptoms?: string[];
}

const SymptomChecker = ({ initialSymptoms = [] }: SymptomCheckerProps) => {
  const [symptoms, setSymptoms] = useState<string[]>(initialSymptoms);
  const [searchTerm, setSearchTerm] = useState("");
  const [showResults, setShowResults] = useState(false);
  const queryClient = useQueryClient();

  // Query for analyzing symptoms
  const { data: conditionMatches, isLoading: analyzingSymptoms, refetch } = useQuery<ConditionMatch[]>({
    queryKey: ['/api/symptoms/analyze', symptoms],
    enabled: symptoms.length > 0,
  });

  // Query for symptom search
  const { data: searchResults, isLoading: searchingSymptoms } = useQuery<Symptom[]>({
    queryKey: ['/api/symptoms/search', searchTerm],
    enabled: searchTerm.length >= 2 && showResults,
  });

  // Remove symptom mutation
  const removeSymptom = useMutation({
    mutationFn: (symptomName: string) => {
      const updatedSymptoms = symptoms.filter(sym => sym !== symptomName);
      setSymptoms(updatedSymptoms);
      return Promise.resolve();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/symptoms/analyze'] });
    }
  });

  // Add symptom mutation
  const addSymptom = useMutation({
    mutationFn: (symptomName: string) => {
      if (!symptoms.includes(symptomName)) {
        setSymptoms([...symptoms, symptomName]);
      }
      setSearchTerm("");
      setShowResults(false);
      return Promise.resolve();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/symptoms/analyze'] });
    }
  });

  const handleReset = () => {
    setSymptoms([]);
    queryClient.invalidateQueries({ queryKey: ['/api/symptoms/analyze'] });
  };

  const handleSaveResults = () => {
    console.log("Save results clicked");
    // Implement save functionality
  };

  const getMatchColor = (matchPercentage: number) => {
    if (matchPercentage >= 75) return "bg-primary";
    if (matchPercentage >= 50) return "bg-warning";
    return "bg-neutral-400";
  };

  return (
    <Card className="bg-white rounded-xl shadow-md overflow-hidden p-6">
      <div className="mb-6">
        <h3 className="font-heading font-medium mb-2">Selected Symptoms</h3>
        <div className="flex flex-wrap gap-2">
          {symptoms.map((symptom, index) => (
            <Badge
              key={index}
              variant="outline"
              className="bg-neutral-100 rounded-full px-3 py-1 text-sm flex items-center"
            >
              {symptom}
              <button
                className="ml-1 text-neutral-400 hover:text-neutral-600"
                onClick={() => removeSymptom.mutate(symptom)}
              >
                <i className="material-icons text-sm">close</i>
              </button>
            </Badge>
          ))}
          <div className="relative">
            <Badge
              variant="outline"
              className="bg-primary bg-opacity-10 rounded-full px-3 py-1 text-sm flex items-center text-primary cursor-pointer"
              onClick={() => setShowResults(!showResults)}
            >
              <i className="material-icons text-sm mr-1">add</i>
              Add symptom
            </Badge>
            
            {showResults && (
              <Card className="absolute top-full left-0 mt-1 w-64 z-10 p-2">
                <input
                  type="text"
                  className="w-full p-2 border rounded mb-2"
                  placeholder="Type symptom name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  autoFocus
                />
                
                {searchingSymptoms ? (
                  <div className="p-2 text-center">
                    <i className="material-icons animate-spin">refresh</i> Searching...
                  </div>
                ) : searchResults && searchResults.length > 0 ? (
                  <div className="max-h-48 overflow-y-auto">
                    {searchResults.map((symptom, idx) => (
                      <div
                        key={idx}
                        className="p-2 hover:bg-neutral-100 cursor-pointer"
                        onClick={() => addSymptom.mutate(symptom.name)}
                      >
                        {symptom.name}
                      </div>
                    ))}
                  </div>
                ) : searchTerm.length >= 2 ? (
                  <div className="p-2 text-center text-neutral-500">
                    No symptoms found
                  </div>
                ) : (
                  <div className="p-2 text-center text-neutral-500">
                    Type to search for symptoms
                  </div>
                )}
                
                {/* Sample symptom suggestions for UI demonstration */}
                {!searchResults?.length && searchTerm.length < 2 && (
                  <div className="max-h-48 overflow-y-auto">
                    {["Headache", "Fatigue", "Dizziness", "Fever", "Cough", "Sore throat"].map((sym, idx) => (
                      <div
                        key={idx}
                        className="p-2 hover:bg-neutral-100 cursor-pointer"
                        onClick={() => addSymptom.mutate(sym)}
                      >
                        {sym}
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            )}
          </div>
        </div>
      </div>
      
      {symptoms.length > 0 && (
        <div className="mb-6">
          <h3 className="font-heading font-medium mb-4">Possible Conditions</h3>
          
          {analyzingSymptoms ? (
            <div className="p-4 text-center">
              <i className="material-icons animate-spin mr-2">refresh</i>
              Analyzing your symptoms...
            </div>
          ) : conditionMatches && conditionMatches.length > 0 ? (
            <div className="border rounded-lg divide-y">
              {conditionMatches.map((condition, index) => (
                <div key={index} className="p-4 hover:bg-neutral-50">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">{condition.name}</h4>
                      <p className="text-sm text-neutral-500">{condition.matchPercentage}% match with your symptoms</p>
                    </div>
                    <div className="flex items-center">
                      <div className="w-16 bg-neutral-200 rounded-full h-2 mr-2">
                        <div 
                          className={`${getMatchColor(condition.matchPercentage)} rounded-full h-2`} 
                          style={{ width: `${condition.matchPercentage}%` }}
                        ></div>
                      </div>
                      <Button 
                        variant="link" 
                        className="text-primary hover:underline text-sm"
                        onClick={() => console.log(`View details for ${condition.name}`)}
                      >
                        Details
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-4 text-center border rounded-lg">
              <p>No conditions matched your symptoms. Try adding more symptoms for better results.</p>
            </div>
          )}
        </div>
      )}
      
      <div className="bg-neutral-50 rounded-lg p-4 mb-6">
        <div className="flex items-start">
          <i className="material-icons text-neutral-500 mr-2">info</i>
          <p className="text-sm text-neutral-600">
            This tool is for informational purposes only and should not replace professional medical advice. 
            If you're experiencing severe symptoms, please seek immediate medical attention.
          </p>
        </div>
      </div>
      
      <div className="flex flex-wrap justify-between">
        <Button 
          variant="outline" 
          className="px-4 py-2 border border-primary text-primary rounded-lg hover:bg-primary hover:bg-opacity-10 mb-2 sm:mb-0"
          onClick={handleReset}
        >
          <i className="material-icons mr-1 text-sm">restart_alt</i>
          Reset
        </Button>
        <div className="flex flex-wrap gap-2">
          <Button 
            variant="outline" 
            className="px-4 py-2 border border-primary text-primary rounded-lg hover:bg-primary hover:bg-opacity-10"
            onClick={handleSaveResults}
            disabled={symptoms.length === 0 || !conditionMatches?.length}
          >
            <i className="material-icons mr-1 text-sm">bookmark</i>
            Save Results
          </Button>
          <Link href="/nearby-services">
            <Button 
              className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark"
            >
              <i className="material-icons mr-1 text-sm">location_on</i>
              Find Nearby Doctor
            </Button>
          </Link>
        </div>
      </div>
    </Card>
  );
};

export default SymptomChecker;
