import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <i className="material-icons text-primary mr-2">medical_services</i>
          <h1 className="text-xl font-heading font-semibold">HealthGuide</h1>
        </div>
        
        <div className="hidden md:flex space-x-4">
          <Button variant="outline" className="rounded-full border-primary text-primary">
            <i className="material-icons text-sm mr-1">notifications</i>
            <span className="text-sm">Alerts</span>
          </Button>
          <Link href="/settings">
            <Button variant="outline" className="rounded-full border-primary text-primary">
              <i className="material-icons text-sm mr-1">settings</i>
              <span className="text-sm">Settings</span>
            </Button>
          </Link>
          <Link href="/profile">
            <Button className="rounded-full bg-primary text-white flex items-center">
              <i className="material-icons text-sm mr-1">account_circle</i>
              <span className="text-sm">My Profile</span>
            </Button>
          </Link>
        </div>
        
        <button 
          className="block md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <i className="material-icons">{isMenuOpen ? 'close' : 'menu'}</i>
        </button>
      </div>
      
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg p-4">
          <div className="flex flex-col space-y-2">
            <Button variant="outline" className="justify-start rounded-full border-primary text-primary">
              <i className="material-icons text-sm mr-2">notifications</i>
              <span className="text-sm">Alerts</span>
            </Button>
            <Link href="/settings" onClick={() => setIsMenuOpen(false)}>
              <Button variant="outline" className="justify-start w-full rounded-full border-primary text-primary flex items-center">
                <i className="material-icons text-sm mr-2">settings</i>
                <span className="text-sm">Settings</span>
              </Button>
            </Link>
            <Link href="/profile" onClick={() => setIsMenuOpen(false)}>
              <Button className="justify-start w-full rounded-full bg-primary text-white flex items-center">
                <i className="material-icons text-sm mr-2">account_circle</i>
                <span className="text-sm">My Profile</span>
              </Button>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
