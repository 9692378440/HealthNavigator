import { db } from "./index";
import * as schema from "@shared/schema";
import { v4 as uuidv4 } from "uuid";

async function seed() {
  try {
    console.log("Starting database seeding...");

    // Create mock user
    const userId = "1";
    await db.insert(schema.users).values({
      id: userId,
      username: "testuser",
      password: "password123", // In a real app, this would be hashed
      email: "user@example.com",
      firstName: "John",
      lastName: "Doe",
      createdAt: new Date()
    }).onConflictDoNothing();
    console.log("Added test user");

    // Seed medicines
    const medicineIds = await seedMedicines();
    console.log("Added medicines");

    // Seed popular medicines
    await seedPopularMedicines(medicineIds);
    console.log("Added popular medicines");

    // Seed drug interactions
    await seedDrugInteractions();
    console.log("Added drug interactions");

    // Seed symptoms and conditions
    const { symptomIds, conditionIds } = await seedSymptomsAndConditions();
    console.log("Added symptoms and conditions");

    // Seed symptom-condition mappings
    await seedSymptomConditionMappings(symptomIds, conditionIds);
    console.log("Added symptom-condition mappings");

    // Seed common conditions
    await seedCommonConditions(conditionIds);
    console.log("Added common conditions");

    // Seed medical services
    await seedMedicalServices();
    console.log("Added medical services");

    // Seed user data
    await seedUserData(userId, medicineIds);
    console.log("Added user data");

    console.log("Database seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}

async function seedMedicines() {
  const medicineData = [
    {
      id: uuidv4(),
      name: "Lisinopril",
      category: "ACE Inhibitor",
      dosage: "10-40 mg daily",
      form: "Oral tablet",
      genericAvailable: true,
      prescriptionRequired: true,
      uses: "Treatment of high blood pressure (hypertension), heart failure, and post-heart attack recovery.",
      sideEffects: [
        { name: "Dizziness", severity: "high" },
        { name: "Dry cough", severity: "medium" },
        { name: "Headache", severity: "medium" },
        { name: "Fatigue", severity: "low" }
      ],
      imageUrl: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=600",
      description: "Lisinopril is an angiotensin-converting enzyme (ACE) inhibitor primarily used for the treatment of hypertension (high blood pressure), congestive heart failure, and heart attacks. It works by relaxing blood vessels, allowing blood to flow more smoothly and making the heart pump more efficiently.",
      mechanismOfAction: "Lisinopril blocks the formation of angiotensin II, a substance that causes blood vessels to narrow, thereby reducing blood pressure.",
      administration: "Take once daily with or without food. Take it at the same time each day to maintain a consistent level in your bloodstream.",
      missedDose: "If you miss a dose, take it as soon as you remember. If it's close to the time for your next dose, skip the missed dose and continue with your regular schedule. Do not take double doses.",
      contraindications: "Do not use if you are pregnant, planning to become pregnant, or have a history of angioedema. Tell your doctor about all medical conditions, especially kidney problems, liver disease, or diabetes.",
      specialPopulations: "Use with caution in elderly patients. Dosage adjustments may be needed for patients with kidney impairment.",
      genericAlternatives: ["Enalapril", "Ramipril", "Benazepril"],
      brandAlternatives: ["Prinivil", "Zestril"]
    },
    {
      id: uuidv4(),
      name: "Metformin",
      category: "Antidiabetic",
      dosage: "500-2000 mg daily",
      form: "Oral tablet",
      genericAvailable: true,
      prescriptionRequired: true,
      uses: "Treatment of type 2 diabetes mellitus, especially in overweight and obese people.",
      sideEffects: [
        { name: "Nausea", severity: "medium" },
        { name: "Diarrhea", severity: "medium" },
        { name: "Stomach upset", severity: "low" },
        { name: "Metallic taste", severity: "low" }
      ],
      imageUrl: "https://images.unsplash.com/photo-1628771065518-0d82f1938462?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=600",
      description: "Metformin is the first-line medication for the treatment of type 2 diabetes, particularly in people who are overweight. It helps control blood sugar levels by improving how your body responds to insulin and reducing the amount of sugar your liver produces.",
      mechanismOfAction: "Metformin decreases glucose production in the liver, decreases intestinal absorption of glucose, and improves insulin sensitivity by increasing peripheral glucose uptake and utilization."
    },
    {
      id: uuidv4(),
      name: "Atorvastatin",
      category: "Statin",
      dosage: "10-80 mg daily",
      form: "Oral tablet",
      genericAvailable: true,
      prescriptionRequired: true,
      uses: "Treatment of high cholesterol and to lower the risk of heart attack or stroke.",
      sideEffects: [
        { name: "Muscle pain", severity: "medium" },
        { name: "Joint pain", severity: "medium" },
        { name: "Increased blood sugar", severity: "low" },
        { name: "Digestive problems", severity: "low" }
      ]
    },
    {
      id: uuidv4(),
      name: "Levothyroxine",
      category: "Thyroid Hormone",
      dosage: "25-200 mcg daily",
      form: "Oral tablet",
      genericAvailable: true,
      prescriptionRequired: true,
      uses: "Treatment of hypothyroidism and thyroid hormone replacement therapy.",
      sideEffects: [
        { name: "Headache", severity: "low" },
        { name: "Insomnia", severity: "low" },
        { name: "Irritability", severity: "low" },
        { name: "Increased appetite", severity: "low" }
      ]
    },
    {
      id: uuidv4(),
      name: "Ibuprofen",
      category: "NSAID",
      dosage: "200-800 mg every 4-6 hours",
      form: "Oral tablet/capsule",
      genericAvailable: true,
      prescriptionRequired: false,
      uses: "Relief of pain, inflammation, and fever.",
      sideEffects: [
        { name: "Stomach pain", severity: "medium" },
        { name: "Heartburn", severity: "medium" },
        { name: "Dizziness", severity: "low" },
        { name: "Rash", severity: "high" }
      ]
    },
    {
      id: uuidv4(),
      name: "Aspirin",
      category: "NSAID",
      dosage: "81-325 mg daily",
      form: "Oral tablet",
      genericAvailable: true,
      prescriptionRequired: false,
      uses: "Pain relief, fever reduction, prevention of heart attacks and strokes.",
      sideEffects: [
        { name: "Stomach bleeding", severity: "high" },
        { name: "Heartburn", severity: "medium" },
        { name: "Nausea", severity: "low" },
        { name: "Tinnitus", severity: "low" }
      ]
    }
  ];

  const medicineIds = [];
  for (const medicine of medicineData) {
    await db.insert(schema.medicines).values(medicine).onConflictDoNothing();
    medicineIds.push(medicine.id);
  }

  return medicineIds;
}

async function seedPopularMedicines(medicineIds: string[]) {
  const popularMedicinesData = [
    {
      id: uuidv4(),
      medicineId: medicineIds[0],  // Lisinopril
      rank: 1
    },
    {
      id: uuidv4(),
      medicineId: medicineIds[1],  // Metformin
      rank: 2
    },
    {
      id: uuidv4(),
      medicineId: medicineIds[2],  // Atorvastatin
      rank: 3
    },
    {
      id: uuidv4(),
      medicineId: medicineIds[4],  // Ibuprofen
      rank: 4
    },
    {
      id: uuidv4(),
      medicineId: medicineIds[5],  // Aspirin
      rank: 5
    }
  ];

  for (const popularMedicine of popularMedicinesData) {
    await db.insert(schema.popularMedicines).values(popularMedicine).onConflictDoNothing();
  }
}

async function seedDrugInteractions() {
  const drugInteractionsData = [
    {
      id: uuidv4(),
      medicationA: "Lisinopril",
      medicationB: "Aspirin",
      severity: "medium" as const,
      description: "High doses of aspirin may reduce the effectiveness of lisinopril. Monitor blood pressure and consult your doctor if concerned."
    },
    {
      id: uuidv4(),
      medicationA: "Lisinopril",
      medicationB: "Ibuprofen",
      severity: "low" as const,
      description: "Occasional use of ibuprofen with lisinopril is generally safe, but regular use may reduce the blood pressure-lowering effect."
    },
    {
      id: uuidv4(),
      medicationA: "Aspirin",
      medicationB: "Ibuprofen",
      severity: "high" as const,
      description: "This combination may increase the risk of gastrointestinal bleeding. Consider alternative pain relievers or consult your doctor."
    },
    {
      id: uuidv4(),
      medicationA: "Metformin",
      medicationB: "Atorvastatin",
      severity: "low" as const,
      description: "Generally a safe combination, but monitor for any muscle pain or weakness."
    }
  ];

  for (const interaction of drugInteractionsData) {
    await db.insert(schema.drugInteractions).values(interaction).onConflictDoNothing();
  }

  // Common drug interactions
  const commonInteractionsData = [
    {
      id: uuidv4(),
      name: "NSAID Combination Risk",
      medicationA: "Aspirin",
      medicationB: "Ibuprofen",
      severity: "high" as const,
      description: "Taking multiple NSAIDs together increases the risk of stomach bleeding and ulcers. Choose one NSAID or discuss with your doctor."
    },
    {
      id: uuidv4(),
      name: "Blood Pressure Medication Interaction",
      medicationA: "Lisinopril",
      medicationB: "Potassium Supplements",
      severity: "medium" as const,
      description: "ACE inhibitors like Lisinopril can increase potassium levels. Taking them with potassium supplements may cause dangerous levels of potassium in the blood."
    },
    {
      id: uuidv4(),
      name: "Cholesterol and Antibiotic Interaction",
      medicationA: "Atorvastatin",
      medicationB: "Erythromycin",
      severity: "medium" as const,
      description: "This antibiotic can increase the concentration of statins in your blood, raising the risk of muscle damage. Your doctor may need to adjust your statin dose temporarily."
    },
    {
      id: uuidv4(),
      name: "Common Pain Reliever Interaction",
      medicationA: "Acetaminophen",
      medicationB: "Alcohol",
      severity: "high" as const,
      description: "Combining acetaminophen with alcohol can increase the risk of liver damage. Limit alcohol when taking any medication containing acetaminophen."
    }
  ];

  for (const interaction of commonInteractionsData) {
    await db.insert(schema.commonDrugInteractions).values(interaction).onConflictDoNothing();
  }
}

async function seedSymptomsAndConditions() {
  // Seed symptoms
  const symptomsData = [
    { id: uuidv4(), name: "Headache", description: "Pain or discomfort in the head, scalp, or neck" },
    { id: uuidv4(), name: "Fatigue", description: "Extreme tiredness resulting from mental or physical exertion" },
    { id: uuidv4(), name: "Dizziness", description: "Feeling faint, lightheaded, or unsteady" },
    { id: uuidv4(), name: "Fever", description: "Elevated body temperature above the normal range" },
    { id: uuidv4(), name: "Cough", description: "Sudden expulsion of air from the lungs" },
    { id: uuidv4(), name: "Sore throat", description: "Pain or irritation in the throat" },
    { id: uuidv4(), name: "Nausea", description: "Feeling of sickness with an inclination to vomit" },
    { id: uuidv4(), name: "Vomiting", description: "Forceful expulsion of stomach contents through the mouth" },
    { id: uuidv4(), name: "Chest pain", description: "Discomfort or pain in the chest area" },
    { id: uuidv4(), name: "Shortness of breath", description: "Difficulty breathing or feeling like you can't get enough air" }
  ];

  const symptomIds = [];
  for (const symptom of symptomsData) {
    await db.insert(schema.symptoms).values(symptom).onConflictDoNothing();
    symptomIds.push(symptom.id);
  }

  // Seed conditions
  const conditionsData = [
    { 
      id: uuidv4(), 
      name: "Migraine", 
      description: "A headache of varying intensity, often accompanied by nausea and sensitivity to light and sound",
      totalSymptoms: 4
    },
    { 
      id: uuidv4(), 
      name: "Common Cold", 
      description: "A viral infectious disease of the upper respiratory tract affecting primarily the nose",
      totalSymptoms: 5
    },
    { 
      id: uuidv4(), 
      name: "Influenza", 
      description: "A contagious respiratory illness caused by influenza viruses",
      totalSymptoms: 6
    },
    { 
      id: uuidv4(), 
      name: "Hypertension", 
      description: "High blood pressure condition, often with no symptoms but can lead to serious health problems",
      totalSymptoms: 3
    },
    { 
      id: uuidv4(), 
      name: "Dehydration", 
      description: "A condition that occurs when the body loses more fluids than it takes in",
      totalSymptoms: 4
    },
    { 
      id: uuidv4(), 
      name: "Anxiety", 
      description: "A feeling of worry, nervousness, or unease about something with an uncertain outcome",
      totalSymptoms: 5
    }
  ];

  const conditionIds = [];
  for (const condition of conditionsData) {
    await db.insert(schema.conditions).values(condition).onConflictDoNothing();
    conditionIds.push(condition.id);
  }

  return { symptomIds, conditionIds };
}

async function seedSymptomConditionMappings(symptomIds: string[], conditionIds: string[]) {
  // Define mappings between symptoms and conditions
  const mappings = [
    // Migraine symptoms
    { symptomId: symptomIds[0], conditionId: conditionIds[0] }, // Headache - Migraine
    { symptomId: symptomIds[2], conditionId: conditionIds[0] }, // Dizziness - Migraine
    { symptomId: symptomIds[6], conditionId: conditionIds[0] }, // Nausea - Migraine
    
    // Common Cold symptoms
    { symptomId: symptomIds[3], conditionId: conditionIds[1] }, // Fever - Common Cold
    { symptomId: symptomIds[4], conditionId: conditionIds[1] }, // Cough - Common Cold
    { symptomId: symptomIds[5], conditionId: conditionIds[1] }, // Sore throat - Common Cold
    { symptomId: symptomIds[1], conditionId: conditionIds[1] }, // Fatigue - Common Cold
    
    // Influenza symptoms
    { symptomId: symptomIds[3], conditionId: conditionIds[2] }, // Fever - Influenza
    { symptomId: symptomIds[4], conditionId: conditionIds[2] }, // Cough - Influenza
    { symptomId: symptomIds[1], conditionId: conditionIds[2] }, // Fatigue - Influenza
    { symptomId: symptomIds[0], conditionId: conditionIds[2] }, // Headache - Influenza
    { symptomId: symptomIds[8], conditionId: conditionIds[2] }, // Chest pain - Influenza
    
    // Hypertension symptoms
    { symptomId: symptomIds[0], conditionId: conditionIds[3] }, // Headache - Hypertension
    { symptomId: symptomIds[2], conditionId: conditionIds[3] }, // Dizziness - Hypertension
    { symptomId: symptomIds[9], conditionId: conditionIds[3] }, // Shortness of breath - Hypertension
    
    // Dehydration symptoms
    { symptomId: symptomIds[2], conditionId: conditionIds[4] }, // Dizziness - Dehydration
    { symptomId: symptomIds[1], conditionId: conditionIds[4] }, // Fatigue - Dehydration
    { symptomId: symptomIds[0], conditionId: conditionIds[4] }, // Headache - Dehydration
    
    // Anxiety symptoms
    { symptomId: symptomIds[8], conditionId: conditionIds[5] }, // Chest pain - Anxiety
    { symptomId: symptomIds[9], conditionId: conditionIds[5] }, // Shortness of breath - Anxiety
    { symptomId: symptomIds[2], conditionId: conditionIds[5] }, // Dizziness - Anxiety
    { symptomId: symptomIds[6], conditionId: conditionIds[5] }, // Nausea - Anxiety
  ];

  for (const mapping of mappings) {
    await db.insert(schema.symptomConditionMap).values({
      id: uuidv4(),
      ...mapping
    }).onConflictDoNothing();
  }
}

async function seedCommonConditions(conditionIds: string[]) {
  const commonConditionsData = [
    {
      id: uuidv4(),
      name: "Migraine",
      conditionId: conditionIds[0]
    },
    {
      id: uuidv4(),
      name: "Common Cold",
      conditionId: conditionIds[1]
    },
    {
      id: uuidv4(),
      name: "Influenza",
      conditionId: conditionIds[2]
    },
    {
      id: uuidv4(),
      name: "Hypertension",
      conditionId: conditionIds[3]
    }
  ];

  for (const commonCondition of commonConditionsData) {
    await db.insert(schema.commonConditions).values(commonCondition).onConflictDoNothing();
  }
}

async function seedMedicalServices() {
  const medicalServicesData = [
    {
      id: uuidv4(),
      name: "City General Hospital",
      type: "hospital" as const,
      address: "123 Main St, Cityville, CA",
      phone: "555-123-4567",
      rating: 4.8,
      openNow: true,
      hoursToday: "Open 24/7",
      lat: 37.7749,
      lng: -122.4194
    },
    {
      id: uuidv4(),
      name: "HealthyRx Pharmacy",
      type: "pharmacy" as const,
      address: "456 Oak Ave, Cityville, CA",
      phone: "555-765-4321",
      rating: 4.5,
      openNow: true,
      hoursToday: "Open until 9PM",
      lat: 37.7739,
      lng: -122.4175
    },
    {
      id: uuidv4(),
      name: "QuickCare Urgent Clinic",
      type: "urgent care" as const,
      address: "789 Maple Rd, Cityville, CA",
      phone: "555-987-6543",
      rating: 4.7,
      openNow: true,
      hoursToday: "Open until 11PM",
      lat: 37.7719,
      lng: -122.4214
    },
    {
      id: uuidv4(),
      name: "Family Medical Center",
      type: "clinic" as const,
      address: "321 Pine St, Cityville, CA",
      phone: "555-456-7890",
      rating: 4.6,
      openNow: true,
      hoursToday: "Open until 6PM",
      lat: 37.7709,
      lng: -122.4165
    },
    {
      id: uuidv4(),
      name: "MedExpress Pharmacy",
      type: "pharmacy" as const,
      address: "654 Cedar Blvd, Cityville, CA",
      phone: "555-234-5678",
      rating: 4.3,
      openNow: true,
      hoursToday: "Open until 10PM",
      lat: 37.7779,
      lng: -122.4145
    },
    {
      id: uuidv4(),
      name: "Memorial Hospital",
      type: "hospital" as const,
      address: "987 Redwood Dr, Cityville, CA",
      phone: "555-876-5432",
      rating: 4.9,
      openNow: true,
      hoursToday: "Open 24/7",
      lat: 37.7699,
      lng: -122.4225
    }
  ];

  for (const service of medicalServicesData) {
    await db.insert(schema.medicalServices).values(service).onConflictDoNothing();
  }
}

async function seedUserData(userId: string, medicineIds: string[]) {
  // Add user allergies
  const allergiesData = [
    {
      id: uuidv4(),
      userId,
      allergyName: "Penicillin"
    },
    {
      id: uuidv4(),
      userId,
      allergyName: "Peanuts"
    }
  ];

  for (const allergy of allergiesData) {
    await db.insert(schema.userAllergies).values(allergy).onConflictDoNothing();
  }

  // Add user conditions
  const conditionsData = [
    {
      id: uuidv4(),
      userId,
      conditionName: "Hypertension"
    },
    {
      id: uuidv4(),
      userId,
      conditionName: "Seasonal Allergies"
    }
  ];

  for (const condition of conditionsData) {
    await db.insert(schema.userConditions).values(condition).onConflictDoNothing();
  }

  // Add user medications
  const medicationsData = [
    {
      id: uuidv4(),
      userId,
      medicineId: medicineIds[0], // Lisinopril
      dosage: "20mg",
      frequency: "Once daily",
      startDate: "2023-01-15",
      notes: "Take in the morning with food",
      createdAt: new Date()
    },
    {
      id: uuidv4(),
      userId,
      medicineId: medicineIds[4], // Ibuprofen
      dosage: "400mg",
      frequency: "As needed for pain",
      notes: "Take with food to avoid stomach upset",
      createdAt: new Date()
    }
  ];

  for (const medication of medicationsData) {
    await db.insert(schema.userMedications).values(medication).onConflictDoNothing();
  }

  // Add user symptom checks
  const symptomChecksData = [
    {
      id: uuidv4(),
      userId,
      date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 1 week ago
      symptoms: ["Headache", "Fatigue", "Dizziness"],
      matchedConditions: [
        {
          id: "1",
          name: "Migraine",
          matchPercentage: 85
        },
        {
          id: "2",
          name: "Dehydration",
          matchPercentage: 70
        },
        {
          id: "3",
          name: "Sinus Infection",
          matchPercentage: 55
        }
      ]
    },
    {
      id: uuidv4(),
      userId,
      date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 1 month ago
      symptoms: ["Cough", "Sore throat", "Fever"],
      matchedConditions: [
        {
          id: "1",
          name: "Common Cold",
          matchPercentage: 90
        },
        {
          id: "2",
          name: "Influenza",
          matchPercentage: 65
        },
        {
          id: "3",
          name: "Strep Throat",
          matchPercentage: 50
        }
      ]
    }
  ];

  for (const check of symptomChecksData) {
    await db.insert(schema.userSymptomChecks).values(check).onConflictDoNothing();
  }
}

seed();
