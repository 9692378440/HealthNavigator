import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { medicineService } from "./services/medicineService";
import { symptomService } from "./services/symptomService";
import { locationService } from "./services/locationService";
import { userService } from "./services/userService";
import { openFDAService } from "./services/openFDAService";
import { z } from "zod";
import { db } from "@db";
import { conditions, symptoms, symptomConditionMap } from "@shared/schema";
import { eq } from "drizzle-orm";

// Validation schemas
const medicationSearchSchema = z.object({
  q: z.string().min(2).optional(),
});

const medicationIdSchema = z.object({
  id: z.string().min(1),
});

const drugInteractionSchema = z.object({
  medications: z.array(z.string()).min(2),
});

const symptomSearchSchema = z.object({
  q: z.string().min(2).optional(),
});

const symptomAnalysisSchema = z.object({
  symptoms: z.array(z.string()).min(1),
});

const nearbyServicesSchema = z.object({
  lat: z.coerce.number(),
  lng: z.coerce.number(),
  radius: z.coerce.number().positive(),
  type: z.string().optional(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Medicine routes
  app.get("/api/medicines/featured", async (req, res) => {
    try {
      const medicine = await medicineService.getFeaturedMedicine();
      res.json(medicine);
    } catch (error) {
      console.error("Error fetching featured medicine:", error);
      res.status(500).json({ message: "Failed to fetch featured medicine" });
    }
  });

  app.get("/api/medicines/popular", async (req, res) => {
    try {
      const medicines = await medicineService.getPopularMedicines();
      res.json(medicines);
    } catch (error) {
      console.error("Error fetching popular medicines:", error);
      res.status(500).json({ message: "Failed to fetch popular medicines" });
    }
  });

  app.get("/api/medicines/search", async (req, res) => {
    try {
      const { q } = medicationSearchSchema.parse(req.query);
      if (!q) {
        return res.json([]);
      }
      const medicines = await medicineService.searchMedicines(q);
      res.json(medicines);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error searching medicines:", error);
      res.status(500).json({ message: "Failed to search medicines" });
    }
  });

  app.get("/api/medicines/:id", async (req, res) => {
    try {
      const { id } = medicationIdSchema.parse(req.params);
      
      try {
        // First try OpenFDA
        const openFDAMedicine = await openFDAService.getDrugDetails(id);
        if (openFDAMedicine) {
          return res.json(openFDAMedicine);
        }
      } catch (fdaError) {
        console.error("Error with OpenFDA medicine fetch:", fdaError);
        // If OpenFDA fails, fall back to local data
      }
      
      // Fall back to local database
      const medicine = await medicineService.getMedicineById(id);
      if (!medicine) {
        return res.status(404).json({ message: "Medicine not found" });
      }
      res.json(medicine);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error fetching medicine:", error);
      res.status(500).json({ message: "Failed to fetch medicine" });
    }
  });

  // Search routes
  app.get("/api/search", async (req, res) => {
    try {
      const { q } = medicationSearchSchema.parse(req.query);
      if (!q) {
        return res.json([]);
      }
      
      try {
        // First try to get real-time data from OpenFDA
        const openFDAResults = await openFDAService.searchAll(q);
        if (openFDAResults && openFDAResults.length > 0) {
          return res.json(openFDAResults);
        }
      } catch (fdaError) {
        console.error("Error with OpenFDA search:", fdaError);
        // If OpenFDA fails, fall back to local data
      }
      
      // Fall back to local data if OpenFDA has no results or fails
      const results = await medicineService.search(q);
      res.json(results);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error searching:", error);
      res.status(500).json({ message: "Failed to perform search" });
    }
  });

  // Drug interaction routes
  app.post("/api/interactions/check", async (req, res) => {
    try {
      const { medications } = drugInteractionSchema.parse(req.body);
      const interactions = await medicineService.checkDrugInteractions(medications);
      res.json(interactions);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error checking drug interactions:", error);
      res.status(500).json({ message: "Failed to check drug interactions" });
    }
  });

  app.get("/api/interactions/common", async (req, res) => {
    try {
      const commonInteractions = await medicineService.getCommonInteractions();
      res.json(commonInteractions);
    } catch (error) {
      console.error("Error fetching common interactions:", error);
      res.status(500).json({ message: "Failed to fetch common interactions" });
    }
  });

  // Symptom routes
  app.get("/api/symptoms/search", async (req, res) => {
    try {
      const { q } = symptomSearchSchema.parse(req.query);
      if (!q) {
        return res.json([]);
      }
      
      try {
        // First try to get real-time data from OpenFDA
        const openFDASymptoms = await openFDAService.searchSymptoms(q);
        if (openFDASymptoms && openFDASymptoms.length > 0) {
          return res.json(openFDASymptoms);
        }
      } catch (fdaError) {
        console.error("Error with OpenFDA symptom search:", fdaError);
        // If OpenFDA fails, fall back to local data
      }
      
      // Fall back to local data
      const symptoms = await symptomService.searchSymptoms(q);
      res.json(symptoms);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error searching symptoms:", error);
      res.status(500).json({ message: "Failed to search symptoms" });
    }
  });

  app.post("/api/symptoms/analyze", async (req, res) => {
    try {
      const { symptoms } = symptomAnalysisSchema.parse(req.body);
      const conditions = await symptomService.analyzeSymptoms(symptoms);
      res.json(conditions);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error analyzing symptoms:", error);
      res.status(500).json({ message: "Failed to analyze symptoms" });
    }
  });

  app.get("/api/conditions/common", async (req, res) => {
    try {
      const commonConditions = await symptomService.getCommonConditions();
      res.json(commonConditions);
    } catch (error) {
      console.error("Error fetching common conditions:", error);
      res.status(500).json({ message: "Failed to fetch common conditions" });
    }
  });
  
  app.get("/api/conditions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Try to get the condition name from the id for better OpenFDA search
      let conditionName;
      if (id === "1" || id === "hypertension") {
        conditionName = "Hypertension";
      } else if (id === "2" || id === "diabetes") {
        conditionName = "Diabetes";
      } else if (id === "3" || id === "migraine") {
        conditionName = "Migraine";
      } else if (id === "4" || id === "arthritis") {
        conditionName = "Arthritis";
      } else if (id.includes("-")) {
        // If the ID is formatted like "condition-name-here", convert to readable name
        conditionName = id.split("-").map(word => 
          word.charAt(0).toUpperCase() + word.slice(1)
        ).join(" ");
      }
      
      try {
        // First try to get real-time data from OpenFDA
        const openFDACondition = await openFDAService.getConditionDetails(id, conditionName);
        if (openFDACondition) {
          return res.json(openFDACondition);
        }
      } catch (fdaError) {
        console.error("Error with OpenFDA condition fetch:", fdaError);
        // If OpenFDA fails, fall back to local data
      }
      
      // Standard response format for fallback data
      let response;
      
      if (id === "1" || id === "hypertension") {
        response = {
          id: "1",
          name: "Hypertension",
          description: "High blood pressure is a common condition in which the long-term force of the blood against your artery walls is high enough that it may eventually cause health problems, such as heart disease.",
          symptoms: ["Headache", "Shortness of breath", "Nosebleeds", "Dizziness"],
          prevalence: "Approximately 1 in 3 adults worldwide",
          treatment: "Lifestyle changes, medication such as ACE inhibitors, diuretics, or beta-blockers",
          prevention: "Regular exercise, healthy diet, reduced salt intake, limiting alcohol, not smoking",
          riskFactors: ["Obesity", "Family history", "Age", "Race", "Stress", "Certain chronic conditions"],
          relatedConditions: ["Heart disease", "Stroke", "Kidney disease"]
        };
      } else if (id === "2" || id === "diabetes") {
        response = {
          id: "2",
          name: "Diabetes Type 2",
          description: "Type 2 diabetes is a chronic condition that affects the way your body metabolizes sugar (glucose). With type 2 diabetes, your body either resists the effects of insulin or doesn't produce enough insulin to maintain normal glucose levels.",
          symptoms: ["Increased thirst", "Frequent urination", "Increased hunger", "Fatigue", "Blurred vision"],
          prevalence: "Affects approximately 462 million people worldwide",
          treatment: "Healthy eating, regular exercise, maintaining a normal weight, monitoring blood sugar, diabetes medications or insulin therapy",
          prevention: "Eat healthy foods, get active, lose excess weight",
          riskFactors: ["Weight", "Fat distribution", "Inactivity", "Family history", "Age", "Prediabetes"],
          relatedConditions: ["Heart and blood vessel disease", "Nerve damage", "Kidney damage", "Eye damage"]
        };
      } else if (id === "3" || id === "migraine") {
        response = {
          id: "3",
          name: "Migraine",
          description: "A migraine is a headache that can cause severe throbbing pain or a pulsing sensation, usually on one side of the head. It's often accompanied by nausea, vomiting, and extreme sensitivity to light and sound.",
          symptoms: ["Throbbing headache", "Sensitivity to light", "Nausea", "Visual disturbances", "Dizziness"],
          prevalence: "Affects approximately 12% of the population",
          treatment: "Pain relievers, triptans, anti-nausea medications, preventive medications",
          prevention: "Identify and avoid triggers, maintain regular sleep and meals, exercise regularly",
          riskFactors: ["Family history", "Hormonal changes", "Stress", "Certain foods", "Sleep changes"],
          relatedConditions: ["Depression", "Anxiety", "Stroke", "Epilepsy"]
        };
      } else if (id === "4" || id === "arthritis") {
        response = {
          id: "4",
          name: "Arthritis",
          description: "Arthritis is the swelling and tenderness of one or more joints. The main symptoms are joint pain and stiffness, which typically worsen with age.",
          symptoms: ["Joint pain", "Stiffness", "Swelling", "Decreased range of motion", "Fatigue"],
          prevalence: "Affects over 50 million adults worldwide",
          treatment: "Pain medications, physical therapy, surgery in severe cases",
          prevention: "Maintain healthy weight, regular exercise, protect joints from injuries",
          riskFactors: ["Age", "Family history", "Previous joint injury", "Obesity"],
          relatedConditions: ["Heart disease", "Diabetes", "Obesity", "Depression"]
        };
      } else {
        // For unknown conditions, if we have a name from the ID, use it
        const name = conditionName || "Condition Information";
        
        response = {
          id: id,
          name: name,
          description: "Detailed information about this condition is currently being updated.",
          symptoms: ["Contact a healthcare professional for specific symptom information"],
          prevalence: "Data being updated",
          treatment: "Consult with a healthcare professional for treatment options",
          prevention: "Consult with a healthcare professional for prevention guidelines",
          riskFactors: ["Consult with a healthcare professional for risk factor information"],
          relatedConditions: []
        };
      }
      
      res.json(response);
    } catch (error) {
      console.error("Error fetching condition:", error);
      res.status(500).json({ message: "Failed to fetch condition details" });
    }
  });

  // Medical services routes
  app.get("/api/services/nearby", async (req, res) => {
    try {
      const { lat, lng, radius, type } = nearbyServicesSchema.parse(req.query);
      const services = await locationService.findNearbyServices(lat, lng, radius, type);
      res.json(services);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error finding nearby services:", error);
      res.status(500).json({ message: "Failed to find nearby services" });
    }
  });

  // User profile routes
  app.get("/api/user/profile", async (req, res) => {
    try {
      // For demonstration, we're using a mock user
      // In a real app, you would get the user ID from the session
      const userId = "1";
      const user = await userService.getUserProfile(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user profile:", error);
      res.status(500).json({ message: "Failed to fetch user profile" });
    }
  });

  app.patch("/api/user/profile", async (req, res) => {
    try {
      // For demonstration, we're using a mock user
      const userId = "1";
      const updatedUser = await userService.updateUserProfile(userId, req.body);
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user profile:", error);
      res.status(500).json({ message: "Failed to update user profile" });
    }
  });

  // User allergies routes
  app.post("/api/user/allergies", async (req, res) => {
    try {
      const userId = "1";
      const { allergy } = req.body;
      const result = await userService.addAllergy(userId, allergy);
      res.json(result);
    } catch (error) {
      console.error("Error adding allergy:", error);
      res.status(500).json({ message: "Failed to add allergy" });
    }
  });

  app.delete("/api/user/allergies/:allergy", async (req, res) => {
    try {
      const userId = "1";
      const { allergy } = req.params;
      const result = await userService.removeAllergy(userId, decodeURIComponent(allergy));
      res.json(result);
    } catch (error) {
      console.error("Error removing allergy:", error);
      res.status(500).json({ message: "Failed to remove allergy" });
    }
  });

  // User conditions routes
  app.post("/api/user/conditions", async (req, res) => {
    try {
      const userId = "1";
      const { condition } = req.body;
      const result = await userService.addCondition(userId, condition);
      res.json(result);
    } catch (error) {
      console.error("Error adding condition:", error);
      res.status(500).json({ message: "Failed to add condition" });
    }
  });

  app.delete("/api/user/conditions/:condition", async (req, res) => {
    try {
      const userId = "1";
      const { condition } = req.params;
      const result = await userService.removeCondition(userId, decodeURIComponent(condition));
      res.json(result);
    } catch (error) {
      console.error("Error removing condition:", error);
      res.status(500).json({ message: "Failed to remove condition" });
    }
  });

  // User medications routes
  app.post("/api/user/save-medicine", async (req, res) => {
    try {
      const userId = "1";
      const { medicineId } = req.body;
      const result = await userService.saveMedicineToProfile(userId, medicineId);
      res.json(result);
    } catch (error) {
      console.error("Error saving medicine to profile:", error);
      res.status(500).json({ message: "Failed to save medicine to profile" });
    }
  });

  app.post("/api/user/medications", async (req, res) => {
    try {
      const userId = "1";
      const result = await userService.addMedication(userId, req.body);
      res.json(result);
    } catch (error) {
      console.error("Error adding medication:", error);
      res.status(500).json({ message: "Failed to add medication" });
    }
  });

  app.patch("/api/user/medications/:id", async (req, res) => {
    try {
      const userId = "1";
      const { id } = req.params;
      const result = await userService.updateMedication(userId, id, req.body);
      res.json(result);
    } catch (error) {
      console.error("Error updating medication:", error);
      res.status(500).json({ message: "Failed to update medication" });
    }
  });

  app.delete("/api/user/medications/:id", async (req, res) => {
    try {
      const userId = "1";
      const { id } = req.params;
      const result = await userService.deleteMedication(userId, id);
      res.json(result);
    } catch (error) {
      console.error("Error deleting medication:", error);
      res.status(500).json({ message: "Failed to delete medication" });
    }
  });

  // User symptom checks routes
  app.post("/api/user/symptom-checks", async (req, res) => {
    try {
      const userId = "1";
      const result = await userService.saveSymptomCheck(userId, req.body);
      res.json(result);
    } catch (error) {
      console.error("Error saving symptom check:", error);
      res.status(500).json({ message: "Failed to save symptom check" });
    }
  });

  app.get("/api/user/symptom-checks", async (req, res) => {
    try {
      const userId = "1";
      const checks = await userService.getSymptomChecks(userId);
      res.json(checks);
    } catch (error) {
      console.error("Error fetching symptom checks:", error);
      res.status(500).json({ message: "Failed to fetch symptom checks" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
