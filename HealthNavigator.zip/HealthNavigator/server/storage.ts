import expressSession from "express-session";
import pgSession from "connect-pg-simple";
import { pool } from "@db";

// Configure session store
const PgStore = pgSession(expressSession);

export const storage = {
  session: expressSession({
    store: new PgStore({
      pool, // Pass the pool used with drizzle
      tableName: "sessions", // Table name to store sessions
      createTableIfMissing: true // Create the sessions table if it doesn't exist
    }),
    secret: process.env.SESSION_SECRET || "healthguide-secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge: 30 * 24 * 60 * 60 * 1000 // 30 days
    }
  })
};