import { db } from "@db";
import { medicalServices } from "@shared/schema";
import { eq, and, lte, gte, like } from "drizzle-orm";

// Distance calculation using Haversine formula
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c; // Distance in km
  return d * 0.621371; // Convert to miles
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}

class LocationService {
  async findNearbyServices(lat: number, lng: number, radius: number, type?: string) {
    // Get all services from the database
    const query = type && type !== "all" 
      ? db.query.medicalServices.findMany({
          where: eq(medicalServices.type, type)
        })
      : db.query.medicalServices.findMany();
    
    const allServices = await query;
    
    // Calculate distances and filter by radius
    const servicesWithDistance = allServices
      .map(service => ({
        ...service,
        distance: calculateDistance(lat, lng, service.lat, service.lng)
      }))
      .filter(service => service.distance <= radius)
      .sort((a, b) => a.distance - b.distance);
    
    return servicesWithDistance;
  }
}

export const locationService = new LocationService();
