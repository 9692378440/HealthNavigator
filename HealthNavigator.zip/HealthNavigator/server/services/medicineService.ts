import { db } from "@db";
import { 
  medicines, 
  popularMedicines,
  drugInteractions,
  commonDrugInteractions,
  conditions,
  symptoms
} from "@shared/schema";
import { eq, or, like, and } from "drizzle-orm";

class MedicineService {
  async getFeaturedMedicine() {
    // Return a featured medicine (for now, just return the first one)
    const medicine = await db.query.medicines.findFirst();
    return medicine;
  }

  async getMedicineById(id: string) {
    const medicine = await db.query.medicines.findFirst({
      where: eq(medicines.id, id)
    });
    return medicine;
  }

  async getPopularMedicines() {
    const populars = await db.query.popularMedicines.findMany({
      with: {
        medicine: true
      }
    });
    
    return populars.map(popular => popular.medicine);
  }

  async searchMedicines(query: string) {
    const likePattern = `%${query}%`;
    const matchedMedicines = await db.query.medicines.findMany({
      where: or(
        like(medicines.name, likePattern),
        like(medicines.category, likePattern)
      )
    });
    
    return matchedMedicines;
  }

  async search(query: string) {
    const likePattern = `%${query}%`;
    
    // Search in medicines
    const matchedMedicines = await db.query.medicines.findMany({
      where: or(
        like(medicines.name, likePattern),
        like(medicines.category, likePattern)
      ),
      limit: 5
    });
    
    // Format the medicines results
    const medicineResults = matchedMedicines.map(medicine => ({
      id: medicine.id,
      title: medicine.name,
      type: "Medication" as const,
      description: medicine.category
    }));
    
    // Search in conditions (diseases)
    const matchedConditions = await db.query.conditions.findMany({
      where: or(
        like(conditions.name, likePattern),
        like(conditions.description, likePattern)
      ),
      limit: 5
    });
    
    // Format the condition results
    const conditionResults = matchedConditions.map(condition => ({
      id: condition.id,
      title: condition.name,
      type: "Disease" as const,
      description: condition.description || "Common medical condition"
    }));
    
    // Search in symptoms
    const matchedSymptoms = await db.query.symptoms.findMany({
      where: like(symptoms.name, likePattern),
      limit: 5
    });
    
    // Format the symptom results
    const symptomResults = matchedSymptoms.map(symptom => ({
      id: symptom.id,
      title: symptom.name,
      type: "Symptom" as const,
      description: symptom.description || "Common health symptom"
    }));
    
    // Combine all results and return
    return [...medicineResults, ...conditionResults, ...symptomResults];
  }

  async checkDrugInteractions(medicationNames: string[]) {
    if (medicationNames.length < 2) {
      return [];
    }
    
    // Find exact + partial matches for the medication names
    const interactions = await db.query.drugInteractions.findMany({
      where: and(
        ...medicationNames.map(name => 
          or(
            like(drugInteractions.medicationA, `%${name}%`),
            like(drugInteractions.medicationB, `%${name}%`)
          )
        )
      )
    });
    
    // Format the interactions
    return interactions.map(interaction => ({
      id: interaction.id,
      medications: [interaction.medicationA, interaction.medicationB],
      severity: interaction.severity,
      description: interaction.description,
    }));
  }

  async getCommonInteractions() {
    const interactions = await db.query.commonDrugInteractions.findMany();
    
    return interactions.map(interaction => ({
      name: interaction.name,
      medications: [interaction.medicationA, interaction.medicationB],
      severity: interaction.severity,
      description: interaction.description,
    }));
  }
}

export const medicineService = new MedicineService();
