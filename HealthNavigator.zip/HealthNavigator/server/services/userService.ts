import { db } from "@db";
import { 
  users, 
  userAllergies, 
  userConditions, 
  userMedications, 
  userSymptomChecks,
  medicines
} from "@shared/schema";
import { eq, and } from "drizzle-orm";
import { v4 as uuidv4 } from "uuid";

class UserService {
  async getUserProfile(userId: string) {
    const user = await db.query.users.findFirst({
      where: eq(users.id, userId),
      with: {
        allergies: true,
        conditions: true,
        medications: {
          with: {
            medicine: true
          }
        },
        symptomChecks: true
      }
    });
    
    if (!user) {
      return null;
    }
    
    // Format user data
    return {
      id: user.id,
      username: user.username,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      dateOfBirth: user.dateOfBirth,
      gender: user.gender,
      phone: user.phone,
      address: user.address,
      allergies: user.allergies.map(allergy => allergy.allergyName),
      conditions: user.conditions.map(condition => condition.conditionName),
      medications: user.medications.map(medication => ({
        id: medication.id,
        medicineId: medication.medicineId,
        medicineName: medication.medicine.name,
        dosage: medication.dosage,
        frequency: medication.frequency,
        startDate: medication.startDate,
        endDate: medication.endDate,
        notes: medication.notes
      })),
      savedSymptomChecks: user.symptomChecks.map(check => ({
        id: check.id,
        date: check.date,
        symptoms: check.symptoms,
        conditions: check.matchedConditions
      }))
    };
  }

  async updateUserProfile(userId: string, profileData: any) {
    await db.update(users).set({
      firstName: profileData.firstName,
      lastName: profileData.lastName,
      email: profileData.email,
      dateOfBirth: profileData.dateOfBirth,
      gender: profileData.gender,
      phone: profileData.phone,
      address: profileData.address
    }).where(eq(users.id, userId));
    
    return this.getUserProfile(userId);
  }

  async addAllergy(userId: string, allergyName: string) {
    // Check if allergy already exists
    const existingAllergy = await db.query.userAllergies.findFirst({
      where: and(
        eq(userAllergies.userId, userId),
        eq(userAllergies.allergyName, allergyName)
      )
    });
    
    if (existingAllergy) {
      return { success: true, message: "Allergy already exists" };
    }
    
    await db.insert(userAllergies).values({
      id: uuidv4(),
      userId,
      allergyName
    });
    
    return { success: true, message: "Allergy added successfully" };
  }

  async removeAllergy(userId: string, allergyName: string) {
    await db.delete(userAllergies)
      .where(and(
        eq(userAllergies.userId, userId),
        eq(userAllergies.allergyName, allergyName)
      ));
    
    return { success: true, message: "Allergy removed successfully" };
  }

  async addCondition(userId: string, conditionName: string) {
    // Check if condition already exists
    const existingCondition = await db.query.userConditions.findFirst({
      where: and(
        eq(userConditions.userId, userId),
        eq(userConditions.conditionName, conditionName)
      )
    });
    
    if (existingCondition) {
      return { success: true, message: "Condition already exists" };
    }
    
    await db.insert(userConditions).values({
      id: uuidv4(),
      userId,
      conditionName
    });
    
    return { success: true, message: "Condition added successfully" };
  }

  async removeCondition(userId: string, conditionName: string) {
    await db.delete(userConditions)
      .where(and(
        eq(userConditions.userId, userId),
        eq(userConditions.conditionName, conditionName)
      ));
    
    return { success: true, message: "Condition removed successfully" };
  }

  async saveMedicineToProfile(userId: string, medicineId: string) {
    // Get the medicine info
    const medicine = await db.query.medicines.findFirst({
      where: eq(medicines.id, medicineId)
    });
    
    if (!medicine) {
      throw new Error("Medicine not found");
    }
    
    // Check if this medicine is already saved
    const existingMedication = await db.query.userMedications.findFirst({
      where: and(
        eq(userMedications.userId, userId),
        eq(userMedications.medicineId, medicineId)
      )
    });
    
    if (existingMedication) {
      return { success: true, message: "Medicine already saved to profile" };
    }
    
    // Add the medicine to user's profile
    await db.insert(userMedications).values({
      id: uuidv4(),
      userId,
      medicineId,
      createdAt: new Date().toISOString()
    });
    
    return { success: true, message: "Medicine saved to profile successfully" };
  }

  async addMedication(userId: string, medication: any) {
    const id = uuidv4();
    
    await db.insert(userMedications).values({
      id,
      userId,
      medicineId: medication.medicineId,
      dosage: medication.dosage,
      frequency: medication.frequency,
      startDate: medication.startDate,
      endDate: medication.endDate,
      notes: medication.notes,
      createdAt: new Date().toISOString()
    });
    
    // Get the added medication with medicine info
    const addedMedication = await db.query.userMedications.findFirst({
      where: eq(userMedications.id, id),
      with: {
        medicine: true
      }
    });
    
    return {
      id: addedMedication?.id,
      medicineId: addedMedication?.medicineId,
      medicineName: addedMedication?.medicine.name,
      dosage: addedMedication?.dosage,
      frequency: addedMedication?.frequency,
      startDate: addedMedication?.startDate,
      endDate: addedMedication?.endDate,
      notes: addedMedication?.notes
    };
  }

  async updateMedication(userId: string, medicationId: string, medication: any) {
    await db.update(userMedications)
      .set({
        dosage: medication.dosage,
        frequency: medication.frequency,
        startDate: medication.startDate,
        endDate: medication.endDate,
        notes: medication.notes
      })
      .where(and(
        eq(userMedications.id, medicationId),
        eq(userMedications.userId, userId)
      ));
    
    // Get the updated medication with medicine info
    const updatedMedication = await db.query.userMedications.findFirst({
      where: eq(userMedications.id, medicationId),
      with: {
        medicine: true
      }
    });
    
    return {
      id: updatedMedication?.id,
      medicineId: updatedMedication?.medicineId,
      medicineName: updatedMedication?.medicine.name,
      dosage: updatedMedication?.dosage,
      frequency: updatedMedication?.frequency,
      startDate: updatedMedication?.startDate,
      endDate: updatedMedication?.endDate,
      notes: updatedMedication?.notes
    };
  }

  async deleteMedication(userId: string, medicationId: string) {
    await db.delete(userMedications)
      .where(and(
        eq(userMedications.id, medicationId),
        eq(userMedications.userId, userId)
      ));
    
    return { success: true, message: "Medication deleted successfully" };
  }

  async saveSymptomCheck(userId: string, symptomCheck: any) {
    const id = uuidv4();
    
    await db.insert(userSymptomChecks).values({
      id,
      userId,
      date: symptomCheck.date || new Date().toISOString(),
      symptoms: symptomCheck.symptoms,
      matchedConditions: symptomCheck.conditions
    });
    
    const savedCheck = await db.query.userSymptomChecks.findFirst({
      where: eq(userSymptomChecks.id, id)
    });
    
    return {
      id: savedCheck?.id,
      date: savedCheck?.date,
      symptoms: savedCheck?.symptoms,
      conditions: savedCheck?.matchedConditions
    };
  }

  async getSymptomChecks(userId: string) {
    const checks = await db.query.userSymptomChecks.findMany({
      where: eq(userSymptomChecks.userId, userId),
      orderBy: (symptomsChecks, { desc }) => [desc(symptomsChecks.date)]
    });
    
    return checks.map(check => ({
      id: check.id,
      date: check.date,
      symptoms: check.symptoms,
      conditions: check.matchedConditions
    }));
  }
}

export const userService = new UserService();
