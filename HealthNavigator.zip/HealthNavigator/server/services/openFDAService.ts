import fetch from 'node-fetch';

// OpenFDA API base URL
const BASE_URL = 'https://api.fda.gov';

// OpenFDA API Endpoints
const DRUG_ENDPOINT = '/drug';
const DEVICE_ENDPOINT = '/device';
const FOOD_ENDPOINT = '/food';

// Define types for OpenFDA responses
interface OpenFDADrugResult {
  id?: string;
  openfda?: {
    application_number?: string[];
    brand_name?: string[];
    generic_name?: string[];
    manufacturer_name?: string[];
    product_type?: string[];
    pharm_class_epc?: string[];
  };
  description?: string[];
  dosage_and_administration?: string[];
  dosage_forms_and_strengths?: string[];
  indications_and_usage?: string[];
  adverse_reactions?: string[];
  warnings?: string[];
  drug_interactions?: string[];
  contraindications?: string[];
  storage_and_handling?: string[];
  mechanism_of_action?: string[];
  specific_populations?: string[];
}

interface OpenFDAResponse {
  meta?: {
    disclaimer?: string;
    terms?: string;
    license?: string;
    last_updated?: string;
    results?: {
      total?: number;
      skip?: number;
      limit?: number;
    };
  };
  results?: OpenFDADrugResult[];
}

class OpenFDAService {
  // Search for drugs by name
  async searchDrugs(query: string, limit: number = 10) {
    try {
      const response = await fetch(
        `${BASE_URL}${DRUG_ENDPOINT}/label.json?search=openfda.brand_name:"${query}"+openfda.generic_name:"${query}"&limit=${limit}`
      );
      
      if (!response.ok) {
        throw new Error(`OpenFDA API returned ${response.status}`);
      }
      
      const data = await response.json() as OpenFDAResponse;
      
      // Extract relevant information and format it
      if (data.results && data.results.length > 0) {
        return data.results.map((drug: OpenFDADrugResult) => {
          const brandName = drug.openfda?.brand_name?.[0] || 'Unknown';
          const genericName = drug.openfda?.generic_name?.[0] || 'Unknown';
          const manufacturerName = drug.openfda?.manufacturer_name?.[0] || 'Unknown';
          
          return {
            id: drug.id || drug.openfda?.application_number?.[0] || Math.random().toString(36).substring(7),
            name: brandName,
            genericName: genericName,
            category: drug.openfda?.pharm_class_epc?.[0] || 'Not specified',
            manufacturer: manufacturerName,
            description: drug.description?.[0] || '',
            dosage: drug.dosage_and_administration?.[0] || '',
            warnings: drug.warnings?.[0] || '',
            sideEffects: drug.adverse_reactions?.[0] || '',
            interactions: drug.drug_interactions?.[0] || '',
            contraindications: drug.contraindications?.[0] || '',
            storage: drug.storage_and_handling?.[0] || '',
          };
        });
      }
      
      return [];
    } catch (error) {
      console.error('Error searching OpenFDA drugs:', error);
      throw error;
    }
  }
  
  // Get detailed drug information
  async getDrugDetails(drugId: string) {
    try {
      // Since OpenFDA doesn't provide direct ID lookup, 
      // we'll use application_number or other identifiers if available
      const response = await fetch(
        `${BASE_URL}${DRUG_ENDPOINT}/label.json?search=id:"${drugId}"&limit=1`
      );
      
      if (!response.ok) {
        // If direct ID search fails, attempt using openfda.application_number
        const appResponse = await fetch(
          `${BASE_URL}${DRUG_ENDPOINT}/label.json?search=openfda.application_number:"${drugId}"&limit=1`
        );
        
        if (!appResponse.ok) {
          throw new Error(`OpenFDA API returned ${appResponse.status}`);
        }
        
        const data = await appResponse.json();
        if (data.results && data.results.length > 0) {
          const drug = data.results[0];
          return this.formatDrugDetails(drug);
        }
      } else {
        const data = await response.json();
        if (data.results && data.results.length > 0) {
          const drug = data.results[0];
          return this.formatDrugDetails(drug);
        }
      }
      
      throw new Error('Drug not found');
    } catch (error) {
      console.error('Error fetching drug details from OpenFDA:', error);
      throw error;
    }
  }
  
  // Helper to format drug details
  private formatDrugDetails(drug: any) {
    const brandName = drug.openfda?.brand_name?.[0] || 'Unknown';
    const genericName = drug.openfda?.generic_name?.[0] || 'Unknown';
    const manufacturerName = drug.openfda?.manufacturer_name?.[0] || 'Unknown';
    
    // Parse side effects into a structured format
    const sideEffectsRaw = drug.adverse_reactions?.[0] || '';
    const sideEffects = this.parseSideEffects(sideEffectsRaw);
    
    return {
      id: drug.id || drug.openfda?.application_number?.[0] || Math.random().toString(36).substring(7),
      name: brandName,
      genericName: genericName,
      category: drug.openfda?.pharm_class_epc?.[0] || 'Not specified',
      manufacturer: manufacturerName,
      description: drug.description?.[0] || '',
      dosage: drug.dosage_and_administration?.[0] || '',
      form: drug.dosage_forms_and_strengths?.[0] || '',
      genericAvailable: !!genericName && genericName !== 'Unknown',
      prescriptionRequired: drug.openfda?.product_type?.[0] !== 'OTC',
      uses: drug.indications_and_usage?.[0] || '',
      sideEffects: sideEffects,
      warnings: drug.warnings?.[0] || '',
      interactions: drug.drug_interactions?.[0] || '',
      contraindications: drug.contraindications?.[0] || '',
      storage: drug.storage_and_handling?.[0] || '',
      mechanismOfAction: drug.mechanism_of_action?.[0] || '',
      administration: drug.dosage_and_administration?.[0] || '',
      missedDose: '',  // Not typically provided by OpenFDA
      specialPopulations: drug.specific_populations?.[0] || '',
    };
  }
  
  // Helper to parse side effects
  private parseSideEffects(sideEffectsText: string) {
    if (!sideEffectsText) return [];
    
    // Common side effect terms to look for
    const commonEffects = [
      'headache', 'nausea', 'dizziness', 'vomiting', 'diarrhea', 
      'fatigue', 'drowsiness', 'insomnia', 'rash', 'fever', 
      'pain', 'anxiety', 'depression', 'constipation'
    ];
    
    const result = [];
    
    // Look for common side effects in the text
    for (const effect of commonEffects) {
      if (sideEffectsText.toLowerCase().includes(effect)) {
        // Determine severity based on language used (simplified approach)
        let severity = 'medium';
        if (sideEffectsText.toLowerCase().includes(`severe ${effect}`) || 
            sideEffectsText.toLowerCase().includes(`serious ${effect}`)) {
          severity = 'high';
        } else if (sideEffectsText.toLowerCase().includes(`mild ${effect}`) || 
                  sideEffectsText.toLowerCase().includes(`rare ${effect}`)) {
          severity = 'low';
        }
        
        result.push({
          name: effect.charAt(0).toUpperCase() + effect.slice(1),
          severity: severity
        });
      }
    }
    
    return result;
  }
  
  // Search for conditions and diseases
  async searchConditions(query: string, limit: number = 10) {
    try {
      // OpenFDA doesn't have a direct conditions API, so we'll search drug labels 
      // for indications and use that to infer conditions
      const response = await fetch(
        `${BASE_URL}${DRUG_ENDPOINT}/label.json?search=indications_and_usage:"${query}"&limit=${limit}`
      );
      
      if (!response.ok) {
        throw new Error(`OpenFDA API returned ${response.status}`);
      }
      
      const data = await response.json();
      
      // Extract unique conditions from indications
      if (data.results && data.results.length > 0) {
        const conditionsSet = new Set<string>();
        const conditionsData: any[] = [];
        
        data.results.forEach((drug: any) => {
          const indications = drug.indications_and_usage?.[0] || '';
          
          // Try to extract condition names from indications text
          const extractedConditions = this.extractConditionsFromText(indications, query);
          
          extractedConditions.forEach((condition: string) => {
            if (!conditionsSet.has(condition.toLowerCase())) {
              conditionsSet.add(condition.toLowerCase());
              
              // Create a condition object
              conditionsData.push({
                id: this.generateIdFromName(condition),
                name: condition,
                description: this.generateConditionDescription(condition, indications),
                type: "Disease",
                relatedMedications: [drug.openfda?.brand_name?.[0] || 'Unknown']
              });
            }
          });
        });
        
        return conditionsData;
      }
      
      return [];
    } catch (error) {
      console.error('Error searching conditions via OpenFDA:', error);
      throw error;
    }
  }
  
  // Get detailed condition information
  async getConditionDetails(conditionId: string, conditionName?: string) {
    try {
      // If we have the condition name, use it for a more precise search
      const searchTerm = conditionName || conditionId;
      
      // Search for drugs that treat this condition to gather information
      const response = await fetch(
        `${BASE_URL}${DRUG_ENDPOINT}/label.json?search=indications_and_usage:"${searchTerm}"&limit=10`
      );
      
      if (!response.ok) {
        throw new Error(`OpenFDA API returned ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.results && data.results.length > 0) {
        // Aggregate information about the condition from multiple drug labels
        const symptomsSet = new Set<string>();
        const treatmentsSet = new Set<string>();
        const relatedMedicationsSet = new Set<string>();
        
        let description = '';
        
        data.results.forEach((drug: any) => {
          const indications = drug.indications_and_usage?.[0] || '';
          const warnings = drug.warnings?.[0] || '';
          const brandName = drug.openfda?.brand_name?.[0] || 'Unknown';
          
          // Extract condition description if we don't have one yet
          if (!description) {
            description = this.extractConditionDescriptionFromIndications(indications, searchTerm);
          }
          
          // Extract symptoms from warnings and indications
          const extractedSymptoms = this.extractSymptomsFromText(indications + ' ' + warnings);
          extractedSymptoms.forEach(symptom => symptomsSet.add(symptom));
          
          // Add medication to related medications
          if (brandName !== 'Unknown') {
            relatedMedicationsSet.add(brandName);
          }
          
          // Extract treatment approaches
          if (indications.includes('treatment') || indications.includes('indicated for')) {
            const treatmentInfo = this.extractTreatmentFromText(indications, brandName);
            if (treatmentInfo) treatmentsSet.add(treatmentInfo);
          }
        });
        
        // Convert sets to arrays
        const symptoms: string[] = [...symptomsSet];
        const treatments: string[] = [...treatmentsSet];
        const relatedMedications: string[] = [...relatedMedicationsSet];
        
        // If we couldn't extract a description, generate one
        if (!description) {
          description = `${searchTerm} is a medical condition that may be treated with various medications including ${relatedMedications.join(', ')}.`;
        }
        
        return {
          id: conditionId,
          name: this.formatConditionName(searchTerm),
          description: description,
          symptoms: symptoms,
          prevalence: "Data not available from OpenFDA",
          treatment: treatments.join('. '),
          prevention: "Consult with a healthcare professional for prevention guidelines",
          relatedMedications: relatedMedications,
          riskFactors: [],
          relatedConditions: []
        };
      }
      
      throw new Error('Condition not found');
    } catch (error) {
      console.error('Error fetching condition details from OpenFDA:', error);
      throw error;
    }
  }
  
  // Helper to extract conditions from text
  private extractConditionsFromText(text: string, query: string): string[] {
    if (!text) return [];
    
    const conditions = [];
    const lowercaseText = text.toLowerCase();
    const lowercaseQuery = query.toLowerCase();
    
    // Look for direct mentions of the query
    if (lowercaseText.includes(lowercaseQuery)) {
      conditions.push(this.formatConditionName(query));
    }
    
    // Common condition indicators in medical text
    const indicators = [
      'indicated for', 'treatment of', 'manage', 'patients with',
      'diagnosed with', 'suffering from'
    ];
    
    // Extract conditions based on these indicators
    for (const indicator of indicators) {
      const index = lowercaseText.indexOf(indicator);
      if (index !== -1) {
        // Get the text following the indicator
        const followingText = text.substring(index + indicator.length).trim();
        
        // Try to extract the condition name (simple approach)
        const conditionMatch = followingText.match(/([A-Z][a-z]+([ -][A-Za-z]+)*)/);
        if (conditionMatch && conditionMatch[0]) {
          conditions.push(conditionMatch[0]);
        }
      }
    }
    
    return [...new Set(conditions)];
  }
  
  // Helper to generate a condition description
  private generateConditionDescription(conditionName: string, indicationsText: string): string {
    // Try to extract a description from the indications text
    const description = this.extractConditionDescriptionFromIndications(indicationsText, conditionName);
    
    if (description) {
      return description;
    }
    
    // Fallback to a generic description
    return `${conditionName} is a medical condition that may require prescription medication.`;
  }
  
  // Helper to extract description from indications
  private extractConditionDescriptionFromIndications(indications: string, conditionName: string): string {
    if (!indications) return '';
    
    const nameLower = conditionName.toLowerCase();
    const indicationsLower = indications.toLowerCase();
    
    // Look for sentences containing the condition name
    const sentences = indications.split(/\.|\?|!/);
    for (const sentence of sentences) {
      if (sentence.toLowerCase().includes(nameLower)) {
        return sentence.trim() + '.';
      }
    }
    
    // If we can't find a specific sentence, return the first sentence of indications
    if (sentences.length > 0 && sentences[0].trim()) {
      return sentences[0].trim() + '.';
    }
    
    return '';
  }
  
  // Helper to extract symptoms from text
  private extractSymptomsFromText(text: string): string[] {
    if (!text) return [];
    
    const symptomsSet = new Set<string>();
    
    // Common symptoms to look for
    const commonSymptoms = [
      'pain', 'fever', 'inflammation', 'swelling', 'rash',
      'nausea', 'vomiting', 'diarrhea', 'constipation',
      'headache', 'dizziness', 'fatigue', 'weakness',
      'cough', 'shortness of breath', 'wheezing',
      'chest pain', 'irregular heartbeat', 'high blood pressure',
      'anxiety', 'depression', 'insomnia'
    ];
    
    const lowerText = text.toLowerCase();
    
    for (const symptom of commonSymptoms) {
      if (lowerText.includes(symptom)) {
        symptomsSet.add(symptom.charAt(0).toUpperCase() + symptom.slice(1));
      }
    }
    
    return Array.from(symptomsSet);
  }
  
  // Helper to extract treatment information
  private extractTreatmentFromText(indications: string, medicationName: string): string {
    if (!indications) return '';
    
    // Look for specific treatment phrases
    const treatmentPhrases = [
      'indicated for the treatment of',
      'for the treatment of',
      'indicated for',
      'used to treat',
      'for treatment of',
      'treats'
    ];
    
    for (const phrase of treatmentPhrases) {
      const index = indications.toLowerCase().indexOf(phrase);
      if (index !== -1) {
        const afterPhrase = indications.substring(index + phrase.length).trim();
        const endOfSentence = afterPhrase.indexOf('.');
        const treatment = endOfSentence > -1 
          ? afterPhrase.substring(0, endOfSentence).trim() 
          : afterPhrase.trim();
        
        if (treatment) {
          return `${medicationName} is ${phrase} ${treatment}`;
        }
      }
    }
    
    return '';
  }
  
  // Helper to format a condition name properly
  private formatConditionName(name: string): string {
    return name
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  }
  
  // Helper to generate a consistent ID from a name
  private generateIdFromName(name: string): string {
    return name.toLowerCase()
      .replace(/[^a-z0-9]/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
  }
  
  // Search for symptoms
  async searchSymptoms(query: string, limit: number = 10) {
    try {
      // OpenFDA doesn't have a direct symptoms API, so we'll search drug labels
      // for adverse reactions and side effects to infer symptoms
      const response = await fetch(
        `${BASE_URL}${DRUG_ENDPOINT}/label.json?search=adverse_reactions:"${query}"&limit=${limit}`
      );
      
      if (!response.ok) {
        throw new Error(`OpenFDA API returned ${response.status}`);
      }
      
      const data = await response.json();
      
      // Extract symptoms from adverse reactions
      if (data.results && data.results.length > 0) {
        const symptomsSet = new Set<string>();
        const symptomsData: any[] = [];
        
        data.results.forEach((drug: any) => {
          const adverseReactions = drug.adverse_reactions?.[0] || '';
          
          // Try to extract symptom names from adverse reactions text
          const matchedSymptoms = this.extractSymptomFromText(adverseReactions, query);
          
          matchedSymptoms.forEach((symptom: string) => {
            if (!symptomsSet.has(symptom.toLowerCase())) {
              symptomsSet.add(symptom.toLowerCase());
              
              // Create a symptom object
              symptomsData.push({
                id: this.generateIdFromName(symptom),
                name: symptom,
                description: this.generateSymptomDescription(symptom, adverseReactions),
                type: "Symptom"
              });
            }
          });
        });
        
        return symptomsData;
      }
      
      return [];
    } catch (error) {
      console.error('Error searching symptoms via OpenFDA:', error);
      throw error;
    }
  }
  
  // Helper to extract symptoms from text
  private extractSymptomFromText(text: string, query: string): string[] {
    if (!text) return [];
    
    const symptoms = [];
    const lowercaseText = text.toLowerCase();
    const lowercaseQuery = query.toLowerCase();
    
    // Look for direct mentions of the query
    if (lowercaseText.includes(lowercaseQuery)) {
      symptoms.push(this.formatConditionName(query));
    }
    
    // Common symptom indicators in medical text
    const commonSymptoms = [
      'pain', 'fever', 'inflammation', 'swelling', 'rash',
      'nausea', 'vomiting', 'diarrhea', 'constipation',
      'headache', 'dizziness', 'fatigue', 'weakness',
      'cough', 'shortness of breath', 'wheezing',
      'chest pain', 'irregular heartbeat', 'high blood pressure',
      'anxiety', 'depression', 'insomnia'
    ];
    
    for (const symptom of commonSymptoms) {
      if (lowercaseText.includes(symptom)) {
        symptoms.push(this.formatConditionName(symptom));
      }
    }
    
    return [...new Set(symptoms)];
  }
  
  // Helper to generate a symptom description
  private generateSymptomDescription(symptomName: string, reactionsText: string): string {
    // Try to extract a description from the reactions text
    const nameLower = symptomName.toLowerCase();
    const reactionsLower = reactionsText.toLowerCase();
    
    // Look for sentences containing the symptom name
    const sentences = reactionsText.split(/\.|\?|!/);
    for (const sentence of sentences) {
      if (sentence.toLowerCase().includes(nameLower)) {
        return sentence.trim() + '.';
      }
    }
    
    // Fallback to a generic description
    return `${symptomName} is a symptom that may be experienced by patients taking certain medications.`;
  }
  
  // Search across drugs, conditions, and symptoms
  async searchAll(query: string, limit: number = 10) {
    try {
      // Perform searches in parallel
      const [drugsPromise, conditionsPromise, symptomsPromise] = await Promise.allSettled([
        this.searchDrugs(query, Math.floor(limit/3)),
        this.searchConditions(query, Math.floor(limit/3)),
        this.searchSymptoms(query, Math.floor(limit/3))
      ]);
      
      // Collect results
      const results = [];
      
      if (drugsPromise.status === 'fulfilled') {
        const drugs = drugsPromise.value;
        drugs.forEach((drug: any) => {
          results.push({
            id: drug.id,
            title: drug.name,
            type: "Medication",
            description: drug.description.substring(0, 100) + (drug.description.length > 100 ? '...' : '')
          });
        });
      }
      
      if (conditionsPromise.status === 'fulfilled') {
        const conditions = conditionsPromise.value;
        conditions.forEach((condition: any) => {
          results.push({
            id: condition.id,
            title: condition.name,
            type: "Disease",
            description: condition.description.substring(0, 100) + (condition.description.length > 100 ? '...' : '')
          });
        });
      }
      
      if (symptomsPromise.status === 'fulfilled') {
        const symptoms = symptomsPromise.value;
        symptoms.forEach((symptom: any) => {
          results.push({
            id: symptom.id,
            title: symptom.name,
            type: "Symptom",
            description: symptom.description.substring(0, 100) + (symptom.description.length > 100 ? '...' : '')
          });
        });
      }
      
      return results;
    } catch (error) {
      console.error('Error performing combined search via OpenFDA:', error);
      throw error;
    }
  }
}

export const openFDAService = new OpenFDAService();