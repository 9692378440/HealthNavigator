import { db } from "@db";
import { 
  symptoms, 
  conditions, 
  symptomConditionMap, 
  commonConditions 
} from "@shared/schema";
import { eq, like, inArray } from "drizzle-orm";

class SymptomService {
  async searchSymptoms(query: string) {
    const likePattern = `%${query}%`;
    const matchedSymptoms = await db.query.symptoms.findMany({
      where: like(symptoms.name, likePattern)
    });
    
    return matchedSymptoms;
  }

  async analyzeSymptoms(symptomNames: string[]) {
    // First, get the IDs of the symptoms
    const foundSymptoms = await db.query.symptoms.findMany({
      where: inArray(symptoms.name, symptomNames)
    });
    
    const symptomIds = foundSymptoms.map(s => s.id);
    
    // If no symptoms found, return empty array
    if (symptomIds.length === 0) {
      return [];
    }
    
    // Find conditions that match these symptoms
    const matchingConditionMaps = await db.query.symptomConditionMap.findMany({
      where: inArray(symptomConditionMap.symptomId, symptomIds),
      with: {
        condition: true
      }
    });
    
    // Group by condition and calculate match percentage
    const conditionCounts: Record<string, { 
      condition: any, 
      matchedSymptomCount: number 
    }> = {};
    
    matchingConditionMaps.forEach(map => {
      if (!conditionCounts[map.conditionId]) {
        conditionCounts[map.conditionId] = {
          condition: map.condition,
          matchedSymptomCount: 0
        };
      }
      conditionCounts[map.conditionId].matchedSymptomCount++;
    });
    
    // Calculate percentages and format results
    const results = Object.values(conditionCounts).map(({ condition, matchedSymptomCount }) => {
      // Get total symptoms for this condition
      const totalSymptomsForCondition = condition.totalSymptoms || matchedSymptomCount;
      
      // Calculate match percentage
      const matchPercentage = Math.round((matchedSymptomCount / totalSymptomsForCondition) * 100);
      
      return {
        id: condition.id,
        name: condition.name,
        matchPercentage: matchPercentage,
        description: condition.description
      };
    });
    
    // Sort by match percentage (descending)
    return results.sort((a, b) => b.matchPercentage - a.matchPercentage);
  }

  async getCommonConditions() {
    const commonConditionsData = await db.query.commonConditions.findMany();
    
    const conditionWithSymptoms = await Promise.all(
      commonConditionsData.map(async (commonCondition) => {
        const conditionData = await db.query.conditions.findFirst({
          where: eq(conditions.id, commonCondition.conditionId)
        });
        
        if (!conditionData) {
          return {
            name: commonCondition.name,
            symptoms: []
          };
        }
        
        // Get symptoms for this condition
        const conditionSymptoms = await db.query.symptomConditionMap.findMany({
          where: eq(symptomConditionMap.conditionId, conditionData.id),
          with: {
            symptom: true
          }
        });
        
        return {
          name: conditionData.name,
          symptoms: conditionSymptoms.map(cs => cs.symptom.name)
        };
      })
    );
    
    return conditionWithSymptoms;
  }
}

export const symptomService = new SymptomService();
